﻿namespace MCQ_Vault
{
    partial class AuthorHP
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            AuthorHP_WelcomeLbL = new Label();
            AuthorHP_CNM = new Button();
            AuthorHP_EM = new Button();
            button1 = new Button();
            SuspendLayout();
            // 
            // AuthorHP_WelcomeLbL
            // 
            AuthorHP_WelcomeLbL.Font = new Font("Segoe UI", 36F, FontStyle.Bold, GraphicsUnit.Point);
            AuthorHP_WelcomeLbL.Location = new Point(197, 35);
            AuthorHP_WelcomeLbL.Name = "AuthorHP_WelcomeLbL";
            AuthorHP_WelcomeLbL.Size = new Size(610, 74);
            AuthorHP_WelcomeLbL.TabIndex = 0;
            // 
            // AuthorHP_CNM
            // 
            AuthorHP_CNM.Font = new Font("Segoe UI Semibold", 19.8000011F, FontStyle.Bold, GraphicsUnit.Point);
            AuthorHP_CNM.Location = new Point(355, 164);
            AuthorHP_CNM.Name = "AuthorHP_CNM";
            AuthorHP_CNM.Size = new Size(278, 77);
            AuthorHP_CNM.TabIndex = 1;
            AuthorHP_CNM.Text = "Create New Module";
            AuthorHP_CNM.UseVisualStyleBackColor = true;
            AuthorHP_CNM.Click += AuthorHP_CNM_Click;
            // 
            // AuthorHP_EM
            // 
            AuthorHP_EM.Font = new Font("Segoe UI Semibold", 19.8000011F, FontStyle.Bold, GraphicsUnit.Point);
            AuthorHP_EM.Location = new Point(355, 260);
            AuthorHP_EM.Name = "AuthorHP_EM";
            AuthorHP_EM.Size = new Size(278, 68);
            AuthorHP_EM.TabIndex = 1;
            AuthorHP_EM.Text = "Edit Modules";
            AuthorHP_EM.UseVisualStyleBackColor = true;
            AuthorHP_EM.Click += AuthorHP_EM_Click;
            // 
            // button1
            // 
            button1.Font = new Font("Segoe UI", 10.8F, FontStyle.Regular, GraphicsUnit.Point);
            button1.Location = new Point(426, 365);
            button1.Name = "button1";
            button1.Size = new Size(155, 58);
            button1.TabIndex = 2;
            button1.Text = "Log out";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click;
            // 
            // AuthorHP
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(985, 533);
            Controls.Add(button1);
            Controls.Add(AuthorHP_EM);
            Controls.Add(AuthorHP_CNM);
            Controls.Add(AuthorHP_WelcomeLbL);
            Name = "AuthorHP";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "AuthorHP";
            Load += AuthorHP_Load;
            ResumeLayout(false);
        }

        #endregion

        private Label AuthorHP_WelcomeLbL;
        private Button AuthorHP_CNM;
        private Button AuthorHP_EM;
        private Button button1;
    }
}