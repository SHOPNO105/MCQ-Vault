using System.Data.SqlClient;
using System.Security.Cryptography.X509Certificates;

namespace MCQ_Vault
{
    public partial class LoginPage : Form
    {
        public LoginPage()
        {
            InitializeComponent();
        }

        private void LoginPage_Signup_Button_Click(object sender, EventArgs e)
        {
            SignupPage sgn = new SignupPage();
            sgn.Show();
        }

        private void LoginPage_Login_Button_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(LoginPage_UsernameTxTBox.Text) || string.IsNullOrWhiteSpace(LoginPage_PassTxTBox.Text))
            {
                MessageBox.Show("Please enter both username and password.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            try
            {
                string ConnectionString = "Data Source=DESKTOP-KVE9T3F\\SQLEXPRESS;Initial Catalog=McqVault;Integrated Security=True;TrustServerCertificate=True";

                using (SqlConnection connection = new SqlConnection(ConnectionString))
                {
                    connection.Open();
                    string username = LoginPage_UsernameTxTBox.Text;
                    string password = LoginPage_PassTxTBox.Text;

                    string CheckLoginDetails = @"SELECT 'Author' as UserType, Author_ID as UserID, Author_Name as UserName 
                                     FROM Author 
                                     WHERE Author_Name = @Name and Author_Password = @password
                                     
                                     UNION ALL  
                                     
                                     SELECT 'Examiner' as UserType, Examiner_ID as UserID, Examiner_Name as UserName 
                                     FROM Examiner 
                                     WHERE Examiner_Name = @Name and Examiner_Password = @password";
                    using (SqlCommand cmd = new SqlCommand(CheckLoginDetails, connection))
                    {
                        cmd.Parameters.AddWithValue("@Name", username);
                        cmd.Parameters.AddWithValue("@password", password);

                        using (SqlDataReader reader = cmd.ExecuteReader())
                        {
                            if (reader.Read())
                            {
                                string userType = reader["UserType"].ToString();
                                string userName = reader["UserName"].ToString();
                                int userId = Convert.ToInt32(reader["UserID"]);

                                UserSession.CurrentUserName = userName;
                                UserSession.CurrentUserType = userType;
                                UserSession.CurrentUserId = userId;

                                if (userType == "Author")
                                {
                                    AuthorHP Ahp = new AuthorHP();
                                    Ahp.Show();
                                    this.Hide();

                                }
                                else if (userType == "Examiner")
                                {
                                    ExaminerHP Exhp = new ExaminerHP();
                                    Exhp.Show();
                                    this.Hide();

                                }
                            }
                            else
                            {
                                LoginPage_InvalidCredentials.Text = "Invalid Credentials . Check your username and password again";
                            }
                        }
                    }

                }

            }
            catch (SqlException ex)
            {
                MessageBox.Show(
                    "A database error occurred ." + ex.Message,
                    "Database Error",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error
                );
            }
            catch (Exception ex)
            {
                MessageBox.Show(
                    "An unexpected error occurred ." + ex.Message,
                    "Error",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error
                );
            }
        }



        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            SignupPage sign = new SignupPage();
            sign.Show();
        }

        private void LoginPage_Load(object sender, EventArgs e)
        {
            LoginPage_UsernameTxTBox.Clear();
            LoginPage_PassTxTBox.Clear();
        }
    }
}
    

