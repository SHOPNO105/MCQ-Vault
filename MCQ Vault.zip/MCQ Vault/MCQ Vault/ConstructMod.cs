﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Data.SqlTypes;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.StartPanel;

namespace MCQ_Vault
{
    public partial class ConstructMod : Form
    {
        public ConstructMod()
        {
            InitializeComponent();
        }

        private void ConstructMod_OptComboBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (ConstructMod_OptComboBox.SelectedIndex == 0)
            {
                ConstructMod_2OptMust.Text = "Select at least two options";
                ConstructMod_OptATxTBox.Visible = false;
                ConstructMod_OptBTxTBox.Visible = false;
                ConstructMod_OptCTxTBox.Visible = false;
                ConstructMod_OptDTxTBox.Visible = false;
                ConstructMod_OptATxTBox.Clear();
                ConstructMod_OptBTxTBox.Clear();
                ConstructMod_OptCTxTBox.Clear();
                ConstructMod_OptDTxTBox.Clear();
                ConstructMod_OptALbl.Visible = false;
                ConstructMod_OptBLbl.Visible = false;
                ConstructMod_OptCLbl.Visible = false;
                ConstructMod_OptDLbl.Visible = false;
            }

            else if (ConstructMod_OptComboBox.SelectedIndex == 1)
            {

                ConstructMod_OptATxTBox.Visible = true;
                ConstructMod_OptBTxTBox.Visible = true;
                ConstructMod_OptCTxTBox.Visible = false;
                ConstructMod_OptDTxTBox.Visible = false;
                ConstructMod_OptCTxTBox.Clear();
                ConstructMod_OptDTxTBox.Clear();
                ConstructMod_OptALbl.Visible = true;
                ConstructMod_OptBLbl.Visible = true;
                ConstructMod_OptCLbl.Visible = false;
                ConstructMod_OptDLbl.Visible = false;
                ConstructMod_OptARBT.Visible = true;
                ConstructMod_OptBRBT.Visible = true;
                ConstructMod_OptCRBT.Visible = false;
                ConstructMod_OptDRBT.Visible = false;
            }
            else if (ConstructMod_OptComboBox.SelectedIndex == 2)
            {
                ConstructMod_OptATxTBox.Visible = true;
                ConstructMod_OptBTxTBox.Visible = true;
                ConstructMod_OptCTxTBox.Visible = true;
                ConstructMod_OptDTxTBox.Visible = false;
                ConstructMod_OptDTxTBox.Clear();
                ConstructMod_OptALbl.Visible = true;
                ConstructMod_OptBLbl.Visible = true;
                ConstructMod_OptCLbl.Visible = true;
                ConstructMod_OptDLbl.Visible = false;
            }
            else if (ConstructMod_OptComboBox.SelectedIndex == 3)
            {
                ConstructMod_OptATxTBox.Visible = true;
                ConstructMod_OptBTxTBox.Visible = true;
                ConstructMod_OptCTxTBox.Visible = true;
                ConstructMod_OptDTxTBox.Visible = true;
                ConstructMod_OptALbl.Visible = true;
                ConstructMod_OptBLbl.Visible = true;
                ConstructMod_OptCLbl.Visible = true;
                ConstructMod_OptDLbl.Visible = true;
            }
        }

        private void ConstructMod_AddQNBTN_Click(object sender, EventArgs e)
        {
            try
            {
                string ModuleName = ConstructMod_EMNTxTBox.Text;
                string question = ConstructMod_EQNTxTBox.Text;
                string CorrectAnswer = null;
                string ShortExplanation = ConstructMod_ShortExpTxTBox.Text;
                string A_option = ConstructMod_OptATxTBox.Text;
                string B_option = ConstructMod_OptBTxTBox.Text;
                string C_option = ConstructMod_OptCTxTBox.Text;
                string D_option = ConstructMod_OptDTxTBox.Text;

                if (string.IsNullOrWhiteSpace(ModuleName))
                {
                    MessageBox.Show(
                        "Please enter your Module Name.",
                        "Name Cannot remain empty",
                        MessageBoxButtons.OK,
                        MessageBoxIcon.Warning
                    );
                }

                if (string.IsNullOrWhiteSpace(question))
                {
                    MessageBox.Show(
                        "Please enter a Question.",
                        "Question Cannot remain empty",
                        MessageBoxButtons.OK,
                        MessageBoxIcon.Warning
                    );
                }
                if (string.IsNullOrWhiteSpace(ShortExplanation))
                {
                    MessageBox.Show(
                        "Enter Short Explanation ",
                        "For the added MCQ",
                        MessageBoxButtons.OK,
                        MessageBoxIcon.Warning
                    );
                }

                if (!ConstructMod_OptARBT.Checked && !ConstructMod_OptBRBT.Checked &&
           !ConstructMod_OptCRBT.Checked && !ConstructMod_OptDRBT.Checked)
                {
                    MessageBox.Show(
                        "Please select the correct answer.",
                        "Correct Answer Required",
                        MessageBoxButtons.OK,
                        MessageBoxIcon.Warning
                    );
                    return;
                }


                string ConnectionString = "Data Source=DESKTOP-KVE9T3F\\SQLEXPRESS;Initial Catalog=McqVault;Integrated Security=True;TrustServerCertificate=True";
                using (SqlConnection conn = new SqlConnection(ConnectionString))
                {
                    conn.Open();

                    string checkQuestion = "SELECT COUNT(*) FROM Module where Question  = @ques";


                    using (SqlCommand checkQuestionCmd = new SqlCommand(checkQuestion, conn))

                    {
                        checkQuestionCmd.Parameters.Add("@ques", System.Data.SqlDbType.VarChar, 100).Value
                            = ModuleName;

                        int count = Convert.ToInt32(checkQuestionCmd.ExecuteScalar());
                        if (count > 0)
                        {
                            MessageBox.Show("Question Already Exists");
                            return;
                        }

                        string ModuleConstruction = @"INSERT INTO Module(

                                                    Module_Name,
                                                    Question,
                                                    Option_A,
                                                    Option_B,
                                                    Option_C,
                                                    Option_D,
                                                    Correct_Answer,
                                                    Short_Explanation,
                                                    Module_HostId )
   
                                                    VALUES(

                                                    @Mname,
                                                    @ques,
                                                    @FirstOpt,
                                                    @SecondOpt,
                                                    @ThirdOpt,
                                                    @FourthOpt,
                                                    @CorrectAns,
                                                    @ShortExp,
                                                    @hostID ) ";
                        using (SqlCommand cmd = new SqlCommand(ModuleConstruction, conn))
                        {
                            cmd.Parameters.Add("@MName",
                                        System.Data.SqlDbType.VarChar, 100)
                                        .Value = ModuleName;
                            cmd.Parameters.Add("@ques",
                                        System.Data.SqlDbType.VarChar, 1000)
                                        .Value = question;
                            cmd.Parameters.Add("@FirstOpt",
                                        System.Data.SqlDbType.VarChar, 500)
                                        .Value = A_option;
                            cmd.Parameters.Add("@SecondOpt",
                                        System.Data.SqlDbType.VarChar, 500)
                                        .Value = B_option;
                            cmd.Parameters.Add("@ThirdOpt",
                                        System.Data.SqlDbType.VarChar, 500)
                                        .Value = C_option;
                            cmd.Parameters.Add("@FourthOpt",
                                        System.Data.SqlDbType.VarChar, 500)
                                        .Value = D_option;
                            cmd.Parameters.AddWithValue("@hostID", UserSession.CurrentUserId);

                            if (ConstructMod_OptARBT.Checked)
                            {
                                CorrectAnswer = A_option;

                            }
                            else if (ConstructMod_OptBRBT.Checked)
                            {
                                CorrectAnswer = B_option;

                            }
                            else if (ConstructMod_OptCRBT.Checked)
                            {
                                CorrectAnswer = C_option;

                            }
                            else if (ConstructMod_OptDRBT.Checked)
                            {

                                CorrectAnswer = D_option;
                            }

                            cmd.Parameters.Add("@CorrectAns",
                                       System.Data.SqlDbType.VarChar, 100).Value = CorrectAnswer;
                            cmd.Parameters.Add("@ShortExp",
                                       System.Data.SqlDbType.VarChar, 2000).Value = ShortExplanation;


                            cmd.ExecuteNonQuery();

                            MessageBox.Show("Question Added Successfully");

                            ConstructMod_OptATxTBox.Clear();
                            ConstructMod_OptBTxTBox.Clear();
                            ConstructMod_OptCTxTBox.Clear();
                            ConstructMod_OptDTxTBox.Clear();
                            ConstructMod_EQNTxTBox.Clear();
                            ConstructMod_ShortExpTxTBox.Clear();
                            ConstructMod_OptARBT.Checked = false;
                            ConstructMod_OptBRBT.Checked = false;
                            ConstructMod_OptCRBT.Checked = false;
                            ConstructMod_OptDRBT.Checked = false;
                        }
                    }
                }
            }


            catch (SqlException ex)
            {
                MessageBox.Show(
                    "A database error occurred ." + ex.Message,
                    "Database Error",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error
                );
            }
            catch (Exception ex)
            {
                MessageBox.Show(
                    "An unexpected error occurred ." + ex.Message,
                    "Error",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error
                );


            }
        }

        private void ConstructMod_ConfirmModBTN_Click(object sender, EventArgs e)
        {
            AuthorHP au = new AuthorHP();
            au.Show();
            this.Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            AuthorHP auhp = new AuthorHP();
            auhp.Show();
            this.Close();
        }
    }
}
