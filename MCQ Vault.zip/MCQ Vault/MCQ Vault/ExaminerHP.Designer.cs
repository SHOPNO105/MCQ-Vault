﻿namespace MCQ_Vault
{
    partial class ExaminerHP
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            ExaminerHP_WelcomeLbL = new Label();
            ExaminerHP_SearchLbl = new Label();
            ExaminerHP_SearchBox = new TextBox();
            ExaminerHP_StartExamBTN = new Button();
            SuspendLayout();
            // 
            // ExaminerHP_WelcomeLbL
            // 
            ExaminerHP_WelcomeLbL.Font = new Font("Segoe UI", 36F, FontStyle.Bold, GraphicsUnit.Point);
            ExaminerHP_WelcomeLbL.Location = new Point(241, 18);
            ExaminerHP_WelcomeLbL.Name = "ExaminerHP_WelcomeLbL";
            ExaminerHP_WelcomeLbL.Size = new Size(609, 95);
            ExaminerHP_WelcomeLbL.TabIndex = 0;
            // 
            // ExaminerHP_SearchLbl
            // 
            ExaminerHP_SearchLbl.Font = new Font("Segoe UI Semibold", 25.8000011F, FontStyle.Bold, GraphicsUnit.Point);
            ExaminerHP_SearchLbl.Location = new Point(268, 113);
            ExaminerHP_SearchLbl.Name = "ExaminerHP_SearchLbl";
            ExaminerHP_SearchLbl.Size = new Size(528, 47);
            ExaminerHP_SearchLbl.TabIndex = 0;
            ExaminerHP_SearchLbl.Text = "Search For Desired Module";
            // 
            // ExaminerHP_SearchBox
            // 
            ExaminerHP_SearchBox.Location = new Point(319, 181);
            ExaminerHP_SearchBox.Name = "ExaminerHP_SearchBox";
            ExaminerHP_SearchBox.Size = new Size(344, 23);
            ExaminerHP_SearchBox.TabIndex = 1;
            // 
            // ExaminerHP_StartExamBTN
            // 
            ExaminerHP_StartExamBTN.BackColor = Color.LimeGreen;
            ExaminerHP_StartExamBTN.Location = new Point(381, 231);
            ExaminerHP_StartExamBTN.Name = "ExaminerHP_StartExamBTN";
            ExaminerHP_StartExamBTN.Size = new Size(222, 55);
            ExaminerHP_StartExamBTN.TabIndex = 2;
            ExaminerHP_StartExamBTN.Text = "Start Exam";
            ExaminerHP_StartExamBTN.UseVisualStyleBackColor = false;
            ExaminerHP_StartExamBTN.Click += ExaminerHP_StartExamBTN_Click;
            // 
            // ExaminerHP
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(948, 546);
            Controls.Add(ExaminerHP_StartExamBTN);
            Controls.Add(ExaminerHP_SearchBox);
            Controls.Add(ExaminerHP_SearchLbl);
            Controls.Add(ExaminerHP_WelcomeLbL);
            Name = "ExaminerHP";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Examiner";
            Load += ExaminerHP_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label ExaminerHP_WelcomeLbL;
        private Label ExaminerHP_SearchLbl;
        private TextBox ExaminerHP_SearchBox;
        private Button ExaminerHP_StartExamBTN;
    }
}