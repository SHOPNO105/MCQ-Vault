﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace MCQ_Vault
{
    public partial class ExaminerHP : Form
    {
        public ExaminerHP()
        {
            InitializeComponent();
        }

        void AutoCompleteTB()
        {
            try
            {
                string ModSearching = ExaminerHP_SearchBox.Text;


                string Query = "Select * from Module where Module_Name like @ModName";

                string Connection = @"Data Source=DESKTOP-KVE9T3F\SQLEXPRESS;Initial Catalog=McqVault;Integrated Security=True;TrustServerCertificate=True";
                SqlConnection conn = new SqlConnection(Connection);

                conn.Open();

                SqlCommand ModCmd = new SqlCommand(Query, conn);
                ModCmd.Parameters.Add("@ModName", System.Data.SqlDbType.VarChar, 100).Value = ModSearching + "%";
                SqlDataReader Reader = ModCmd.ExecuteReader();

                AutoCompleteStringCollection coll = new AutoCompleteStringCollection();

                while (Reader.Read())
                {
                    coll.Add(Reader.GetString(0));
                }
                ExaminerHP_SearchBox.AutoCompleteSource = AutoCompleteSource.CustomSource;
                ExaminerHP_SearchBox.AutoCompleteMode = AutoCompleteMode.SuggestAppend;
                ExaminerHP_SearchBox.AutoCompleteCustomSource = coll;

                conn.Close();
            }
            catch (SqlException ex)
            {
                MessageBox.Show(
                    "A database error occurred ." + ex.Message,
                    "Database Error",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error
                );
            }
            catch (Exception ex)
            {
                MessageBox.Show(
                    "An unexpected error occurred ." + ex.Message,
                    "Error",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error
                );
            }

        }

        private void ExaminerHP_Load(object sender, EventArgs e)
        {
            ExaminerHP_WelcomeLbL.Text = "Welcome " + UserSession.CurrentUserName;
            AutoCompleteTB();
        }

        private void ExaminerHP_StartExamBTN_Click(object sender, EventArgs e)
        {
            Examination exam = new Examination();
            UserSession.CurrentModule = ExaminerHP_SearchBox.Text;
            exam.Show();
            this.Hide();
        }
        
        
        
    }

}
