﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Data.SqlClient;
using System.Data.SqlTypes;
using System.Diagnostics.CodeAnalysis;
using System.Drawing;
using System.Linq;
using System.Reflection.PortableExecutable;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.ComponentModel.Design.ObjectSelectorEditor;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace MCQ_Vault
{
    public partial class SignupPage : Form
    {
        public SignupPage()
        {
            InitializeComponent();
        }

        private void Signup_Institution_Click(object sender, EventArgs e)
        {

        }

        private void Signup_ConditionsLbL_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            MessageBox.Show("Actually You have to handover all of your personal Data" +
                            " to us . Dont Worry we won't share(we'll sell obviously)" +
                            " your data to anyone . It's private within us(and our partners) ");
        }




        private void Signup_ConfirmRegBTN_Click(object sender, EventArgs e)
        {
           
            string username = Signup_CNTxTBox.Text.Trim();
            string gender = Signup_GenderComboBox.Text.Trim();
            string institution = Signup_InstitutionTxTBox.Text.Trim();

            string password = Signup_CreatePassBox.Text;
            string confirmPassword = Signup_ConfirmPassBox.Text;


            Signup_EightCharBool.Visible = false;
            Signup_MustHaveULNLbL.Visible = false;
            Signup_PasswordXSame.Visible = false;

 

            if (string.IsNullOrWhiteSpace(username))
            {
                MessageBox.Show(
                    "Please enter a username.",
                    "Registration Error",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Warning
                );

                Signup_CNTxTBox.Focus();
                return;
            }
  

            if (string.IsNullOrWhiteSpace(gender))
            {
                MessageBox.Show(
                    "Please select your gender.",
                    "Registration Error",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Warning
                );

                Signup_GenderComboBox.Focus();
                return;
            }

            if (string.IsNullOrWhiteSpace(institution))
            {
                MessageBox.Show(
                    "Please enter your institution.",
                    "Registration Error",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Warning
                );

                Signup_InstitutionTxTBox.Focus();
                return;
            }

            if (!Signup_RoleRadioBTNAuthor.Checked &&
                !Signup_RoleRadioBTNExaminer.Checked)
            {
                MessageBox.Show(
                    "Please select either Author or Examiner.",
                    "Registration Error",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Warning
                );

                return;
            }

            bool hasUppercase = false;
            bool hasLowercase = false;
            bool hasNumber = false;
            bool hasSpace = false;

            foreach (char c in password)
            {
                if (char.IsUpper(c))
                    hasUppercase = true;

                if (char.IsLower(c))
                    hasLowercase = true;

                if (char.IsDigit(c))
                    hasNumber = true;

                if (char.IsWhiteSpace(c))
                    hasSpace = true;
            }


            bool passwordLengthValid = password.Length > 8;


            bool passwordCharactersValid =
                hasUppercase &&
                hasLowercase &&
                hasNumber &&
                !hasSpace;

            bool passwordsMatch = password == confirmPassword;


            if (!passwordLengthValid)
            {
                Signup_EightCharBool.Visible = true;
            }

            if (!passwordCharactersValid)
            {
                Signup_MustHaveULNLbL.Visible = true;
            }

            if (!passwordsMatch)
            {
                Signup_PasswordXSame.Visible = true;
            }


            if (!passwordLengthValid ||
                !passwordCharactersValid ||
                !passwordsMatch)
            {
                return;
            }

            string connectionString =
                @"Data Source=DESKTOP-KVE9T3F\SQLEXPRESS;
          Initial Catalog=McqVault;
          Integrated Security=True;
          TrustServerCertificate=True";


            try
            {
                using (SqlConnection connection =
                       new SqlConnection(connectionString))
                {
                    connection.Open();

                    string checkQuery = "";
                    if (Signup_RoleRadioBTNAuthor.Checked)
                    {
                        checkQuery = @"Select count(*) from Author
                                                where Author_Name = @Name
                                                UNION ALL
                                              SELECT COUNT(*) FROM Examiner
                                                where Examiner_Name = @Name";
                    }
                    else if (Signup_RoleRadioBTNExaminer.Checked)
                    {
                        checkQuery = @"Select count(*) from Examiner
                                                where Examiner_Name = @Name
                                                UNION ALL
                                                SELECT COUNT(*) FROM AUTHOR
                                                 WHERE Author_Name = @Name";
                    }

                    using (SqlCommand CheckCmd = new SqlCommand(checkQuery, connection))
                    {
                        CheckCmd.Parameters.Add("@Name", System.Data.SqlDbType.VarChar, 100).Value = username;
                        using (SqlDataReader Reader = CheckCmd.ExecuteReader())
                        {
                            int count = 0;
                            while (Reader.Read())
                            {
                                count = count + Reader.GetInt32(0);
                            }

                            if (count > 0)
                            {
                                MessageBox.Show("Account Already Exist ");
                                return;
                            }
                        }

                        if (Signup_RoleRadioBTNAuthor.Checked)
                        {
                            string query = @"
                    INSERT INTO Author
                    (
                        Author_Name,
                        Gender,
                        Institution,
                        Author_Password
                    )
                    VALUES
                    (
                        @Name,
                        @Gender,
                        @Institution,
                        @Password
                    )";


                            using (SqlCommand command =
                                   new SqlCommand(query, connection))
                            {
                                command.Parameters.Add("@Name",
                                    System.Data.SqlDbType.VarChar, 100)
                                    .Value = username;

                                command.Parameters.Add("@Gender",
                                    System.Data.SqlDbType.VarChar, 6)
                                    .Value = gender;


                                command.Parameters.Add("@Institution",
                                    System.Data.SqlDbType.VarChar, 100)
                                    .Value = institution;

                                command.Parameters.Add("@Password",
                                    System.Data.SqlDbType.VarChar, 200)
                                    .Value = password;


                                command.ExecuteNonQuery();
                            }

                            MessageBox.Show(
                                "Author account created successfully!",
                                "Registration Successful",
                                MessageBoxButtons.OK,
                                MessageBoxIcon.Information
                            );
                        }

                        else if (Signup_RoleRadioBTNExaminer.Checked)
                        {
                            string query = @"
                    INSERT INTO Examiner
                    (
                        Examiner_Name,
                        Gender,
                        Institution,
                        Examiner_Password
                    )
                    VALUES
                    (
                        @Name,
                        @Gender,
                        @Institution,
                        @Password
                    )";
                            using (SqlCommand command =
                                   new SqlCommand(query, connection))
                            {
                                command.Parameters.Add("@Name",
                                    System.Data.SqlDbType.VarChar, 100)
                                    .Value = username;

                                command.Parameters.Add("@Gender",
                                    System.Data.SqlDbType.VarChar, 6)
                                    .Value = gender;


                                command.Parameters.Add("@Institution",
                                    System.Data.SqlDbType.VarChar, 100)
                                    .Value = institution;

                                command.Parameters.Add("@Password",
                                    System.Data.SqlDbType.VarChar, 200)
                                    .Value = password;


                                command.ExecuteNonQuery();
                            }

                            MessageBox.Show(
                                "Examiner account created successfully!",
                                "Registration Successful",
                                MessageBoxButtons.OK,
                                MessageBoxIcon.Information
                            );
                        }
                    }
                }
            }
            catch (SqlException ex)
            {
                MessageBox.Show(
                    "A database error occurred ." + ex.Message,
                    "Database Error",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error
                );
            }
            catch (Exception ex)
            {
                MessageBox.Show(
                    "An unexpected error occurred ." + ex.Message,
                    "Error",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error
                );
            }
        }
        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            LoginPage LP = new LoginPage();
            LP.Show();
            this.Close();
        }
    }
}

