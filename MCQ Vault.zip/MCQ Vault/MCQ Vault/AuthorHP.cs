﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MCQ_Vault
{
    public partial class AuthorHP : Form
    {
        public AuthorHP()
        {
            InitializeComponent();
        }


        private void AuthorHP_CNM_Click(object sender, EventArgs e)
        {
            ConstructMod conmd = new ConstructMod();
            conmd.Show();
            this.Hide();
        }

        private void AuthorHP_Load(object sender, EventArgs e)
        {
            AuthorHP_WelcomeLbL.Text = "Welcome " + UserSession.CurrentUserName;

        }

        private void AuthorHP_EM_Click(object sender, EventArgs e)
        {
            EditMod em = new EditMod();
            em.Show();
            this.Hide();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show("Are you sure you want to Logout?", "Logout Now", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (result == DialogResult.Yes)
            {
                LoginPage loginPage = new LoginPage();
                loginPage.Show();
                this.Close();
            }
            else
            {
                this.Close();
            }
           
        }
    }
}
