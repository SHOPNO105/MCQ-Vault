﻿using System;
using System.Drawing;
using System.Windows.Forms;

namespace MCQ_Vault
{
    partial class EditMod
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            Edit_Option = new RichTextBox();
            ModuleNameLbL = new Label();
            label5 = new Label();
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            Edit_Question = new RichTextBox();
            label4 = new Label();
            label6 = new Label();
            Delete_Whole_Question = new Button();
            Update_Option = new Button();
            label7 = new Label();
            Delete_Option = new Button();
            Enter_Module_Name = new TextBox();
            Search_Question = new TextBox();
            Update_Question = new Button();
            Select_Option_Number = new ComboBox();
            label8 = new Label();
            richTextBox1 = new RichTextBox();
            label9 = new Label();
            Delete_Ans = new Button();
            Update_Ans = new Button();
            button1 = new Button();
            SuspendLayout();
            // 
            // Edit_Option
            // 
            Edit_Option.Location = new Point(276, 364);
            Edit_Option.Name = "Edit_Option";
            Edit_Option.Size = new Size(272, 30);
            Edit_Option.TabIndex = 0;
            Edit_Option.Text = "";
            // 
            // ModuleNameLbL
            // 
            ModuleNameLbL.Font = new Font("Segoe UI", 13.8F, FontStyle.Regular, GraphicsUnit.Point);
            ModuleNameLbL.Location = new Point(79, 110);
            ModuleNameLbL.Name = "ModuleNameLbL";
            ModuleNameLbL.Size = new Size(179, 30);
            ModuleNameLbL.TabIndex = 2;
            ModuleNameLbL.Text = "Enter module name";
            // 
            // label5
            // 
            label5.Font = new Font("Segoe UI", 48F, FontStyle.Bold, GraphicsUnit.Point);
            label5.ForeColor = SystemColors.ControlText;
            label5.Location = new Point(238, 0);
            label5.Name = "label5";
            label5.Size = new Size(601, 98);
            label5.TabIndex = 3;
            label5.Text = "Module Garage";
            // 
            // label1
            // 
            label1.Font = new Font("Segoe UI", 13.8F, FontStyle.Regular, GraphicsUnit.Point);
            label1.Location = new Point(73, 165);
            label1.Name = "label1";
            label1.Size = new Size(194, 30);
            label1.TabIndex = 2;
            label1.Text = "Search For Question";
            // 
            // label2
            // 
            label2.Font = new Font("Segoe UI", 13.8F, FontStyle.Regular, GraphicsUnit.Point);
            label2.Location = new Point(76, 309);
            label2.Name = "label2";
            label2.Size = new Size(206, 30);
            label2.TabIndex = 2;
            label2.Text = "Select Option Number";
            // 
            // label3
            // 
            label3.Font = new Font("Segoe UI", 13.8F, FontStyle.Regular, GraphicsUnit.Point);
            label3.Location = new Point(73, 364);
            label3.Name = "label3";
            label3.Size = new Size(185, 30);
            label3.TabIndex = 2;
            label3.Text = "Edit Option to edit";
            // 
            // Edit_Question
            // 
            Edit_Question.Location = new Point(276, 212);
            Edit_Question.Name = "Edit_Question";
            Edit_Question.Size = new Size(484, 30);
            Edit_Question.TabIndex = 0;
            Edit_Question.Text = "";
            // 
            // label4
            // 
            label4.Font = new Font("Segoe UI", 13.8F, FontStyle.Regular, GraphicsUnit.Point);
            label4.Location = new Point(128, 212);
            label4.Name = "label4";
            label4.Size = new Size(139, 30);
            label4.TabIndex = 2;
            label4.Text = "Edit Question";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new Point(603, 271);
            label6.Name = "label6";
            label6.Size = new Size(18, 15);
            label6.TabIndex = 4;
            label6.Text = "or";
            // 
            // Delete_Whole_Question
            // 
            Delete_Whole_Question.Location = new Point(629, 258);
            Delete_Whole_Question.Name = "Delete_Whole_Question";
            Delete_Whole_Question.Size = new Size(131, 40);
            Delete_Whole_Question.TabIndex = 5;
            Delete_Whole_Question.Text = "Delete Whole Question";
            Delete_Whole_Question.UseVisualStyleBackColor = true;
            Delete_Whole_Question.Click += Delete_Whole_Question_Click;
            // 
            // Update_Option
            // 
            Update_Option.Location = new Point(555, 354);
            Update_Option.Name = "Update_Option";
            Update_Option.Size = new Size(137, 40);
            Update_Option.TabIndex = 5;
            Update_Option.Text = "Update Option";
            Update_Option.UseVisualStyleBackColor = true;
            Update_Option.Click += Update_Option_Click;
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Location = new Point(698, 372);
            label7.Name = "label7";
            label7.Size = new Size(18, 15);
            label7.TabIndex = 4;
            label7.Text = "or";
            // 
            // Delete_Option
            // 
            Delete_Option.Location = new Point(722, 354);
            Delete_Option.Name = "Delete_Option";
            Delete_Option.Size = new Size(117, 40);
            Delete_Option.TabIndex = 5;
            Delete_Option.Text = "Delete Option";
            Delete_Option.UseVisualStyleBackColor = true;
            Delete_Option.Click += Delete_Option_Click;
            // 
            // Enter_Module_Name
            // 
            Enter_Module_Name.Location = new Point(276, 110);
            Enter_Module_Name.Name = "Enter_Module_Name";
            Enter_Module_Name.Size = new Size(484, 23);
            Enter_Module_Name.TabIndex = 6;
            Enter_Module_Name.TextChanged += Enter_Module_Name_TextChanged;
            // 
            // Search_Question
            // 
            Search_Question.Location = new Point(276, 165);
            Search_Question.Name = "Search_Question";
            Search_Question.Size = new Size(484, 23);
            Search_Question.TabIndex = 6;
            Search_Question.TextChanged += Search_Question_TextChanged;
            // 
            // Update_Question
            // 
            Update_Question.Location = new Point(460, 258);
            Update_Question.Name = "Update_Question";
            Update_Question.Size = new Size(137, 40);
            Update_Question.TabIndex = 5;
            Update_Question.Text = "Update Question";
            Update_Question.UseVisualStyleBackColor = true;
            Update_Question.Click += Update_Question_Click;
            // 
            // Select_Option_Number
            // 
            Select_Option_Number.DropDownStyle = ComboBoxStyle.DropDownList;
            Select_Option_Number.FormattingEnabled = true;
            Select_Option_Number.Items.AddRange(new object[] { "A", "B", "C", "D" });
            Select_Option_Number.Location = new Point(276, 314);
            Select_Option_Number.Name = "Select_Option_Number";
            Select_Option_Number.Size = new Size(103, 23);
            Select_Option_Number.TabIndex = 7;
            Select_Option_Number.SelectedIndexChanged += Select_Option_Number_SelectedIndexChanged;
            // 
            // label8
            // 
            label8.Font = new Font("Segoe UI", 13.8F, FontStyle.Regular, GraphicsUnit.Point);
            label8.Location = new Point(40, 412);
            label8.Name = "label8";
            label8.Size = new Size(230, 30);
            label8.TabIndex = 2;
            label8.Text = "Edit Short Explanation";
            // 
            // richTextBox1
            // 
            richTextBox1.Location = new Point(276, 412);
            richTextBox1.Name = "richTextBox1";
            richTextBox1.Size = new Size(272, 69);
            richTextBox1.TabIndex = 0;
            richTextBox1.Text = "";
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Location = new Point(698, 442);
            label9.Name = "label9";
            label9.Size = new Size(18, 15);
            label9.TabIndex = 4;
            label9.Text = "or";
            // 
            // Delete_Ans
            // 
            Delete_Ans.Location = new Point(722, 424);
            Delete_Ans.Name = "Delete_Ans";
            Delete_Ans.Size = new Size(117, 40);
            Delete_Ans.TabIndex = 5;
            Delete_Ans.Text = "Delete Explanation";
            Delete_Ans.UseVisualStyleBackColor = true;
            Delete_Ans.Click += Delete_Ans_Click;
            // 
            // Update_Ans
            // 
            Update_Ans.Location = new Point(555, 424);
            Update_Ans.Name = "Update_Ans";
            Update_Ans.Size = new Size(137, 40);
            Update_Ans.TabIndex = 5;
            Update_Ans.Text = "Update Explanation";
            Update_Ans.UseVisualStyleBackColor = true;
            Update_Ans.Click += Update_Ans_Click;
            // 
            // button1
            // 
            button1.Location = new Point(460, 503);
            button1.Name = "button1";
            button1.Size = new Size(153, 41);
            button1.TabIndex = 8;
            button1.Text = "Done Editing";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click;
            // 
            // EditMod
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(956, 566);
            Controls.Add(button1);
            Controls.Add(Select_Option_Number);
            Controls.Add(Search_Question);
            Controls.Add(Enter_Module_Name);
            Controls.Add(Update_Question);
            Controls.Add(Update_Ans);
            Controls.Add(Update_Option);
            Controls.Add(Delete_Ans);
            Controls.Add(Delete_Option);
            Controls.Add(label9);
            Controls.Add(label7);
            Controls.Add(Delete_Whole_Question);
            Controls.Add(label6);
            Controls.Add(label5);
            Controls.Add(label8);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label4);
            Controls.Add(label1);
            Controls.Add(ModuleNameLbL);
            Controls.Add(richTextBox1);
            Controls.Add(Edit_Option);
            Controls.Add(Edit_Question);
            Name = "EditMod";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "EditMod";
            Load += EditMod_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion
        private RichTextBox Edit_Option;
        private Label ModuleNameLbL;
        private Label label5;
        private Label label1;
        private Label label2;
        private Label label3;
        private RichTextBox Edit_Question;
        private Label label4;
        private Label label6;
        private Button Delete_Whole_Question;
        private Button Update_Option;
        private Label label7;
        private Button Delete_Option;
        private TextBox Enter_Module_Name;
        private TextBox Search_Question;
        private Button Update_Question;
        private ComboBox Select_Option_Number;
        private Label label8;
        private RichTextBox richTextBox1;
        private Label label9;
        private Button Delete_Ans;
        private Button Update_Ans;
        private Button button1;
    }
}