﻿namespace MCQ_Vault
{
    partial class ConstructMod
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            ConstructMod_LbL = new Label();
            ConstructMod_EMN = new Label();
            ConstructMod_EQ = new Label();
            ConstructMod_EMNTxTBox = new TextBox();
            ConstructMod_EQNTxTBox = new TextBox();
            ConstructMod_NumOfOpt = new Label();
            ConstructMod_OptComboBox = new ComboBox();
            ConstructMod_EOpt = new Label();
            ConstructMod_CorrectAnsLbL = new Label();
            ConstructMod_AddQNBTN = new Button();
            ConstructMod_ConfirmModBTN = new Button();
            ConstructMod_OptATxTBox = new RichTextBox();
            ConstructMod_OptBTxTBox = new RichTextBox();
            ConstructMod_OptCTxTBox = new RichTextBox();
            ConstructMod_OptDTxTBox = new RichTextBox();
            ConstructMod_2OptMust = new Label();
            ConstructMod_ShortExpLbL = new Label();
            ConstructMod_ShortExpTxTBox = new RichTextBox();
            ConstructMod_OptALbl = new Label();
            ConstructMod_OptBLbl = new Label();
            ConstructMod_OptCLbl = new Label();
            ConstructMod_OptDLbl = new Label();
            ConstructMod_OptARBT = new RadioButton();
            ConstructMod_OptBRBT = new RadioButton();
            ConstructMod_OptCRBT = new RadioButton();
            ConstructMod_OptDRBT = new RadioButton();
            button1 = new Button();
            SuspendLayout();
            // 
            // ConstructMod_LbL
            // 
            ConstructMod_LbL.Font = new Font("Segoe UI", 36F, FontStyle.Bold, GraphicsUnit.Point);
            ConstructMod_LbL.Location = new Point(233, 19);
            ConstructMod_LbL.Name = "ConstructMod_LbL";
            ConstructMod_LbL.Size = new Size(536, 74);
            ConstructMod_LbL.TabIndex = 0;
            ConstructMod_LbL.Text = "Construct Module";
            // 
            // ConstructMod_EMN
            // 
            ConstructMod_EMN.Font = new Font("Segoe UI Semibold", 9F, FontStyle.Bold, GraphicsUnit.Point);
            ConstructMod_EMN.Location = new Point(97, 110);
            ConstructMod_EMN.Name = "ConstructMod_EMN";
            ConstructMod_EMN.Size = new Size(149, 25);
            ConstructMod_EMN.TabIndex = 0;
            ConstructMod_EMN.Text = "Enter Module Name";
            // 
            // ConstructMod_EQ
            // 
            ConstructMod_EQ.Font = new Font("Segoe UI Semibold", 9F, FontStyle.Bold, GraphicsUnit.Point);
            ConstructMod_EQ.Location = new Point(124, 154);
            ConstructMod_EQ.Name = "ConstructMod_EQ";
            ConstructMod_EQ.Size = new Size(122, 25);
            ConstructMod_EQ.TabIndex = 0;
            ConstructMod_EQ.Text = "Enter Question";
            // 
            // ConstructMod_EMNTxTBox
            // 
            ConstructMod_EMNTxTBox.Location = new Point(233, 109);
            ConstructMod_EMNTxTBox.Name = "ConstructMod_EMNTxTBox";
            ConstructMod_EMNTxTBox.Size = new Size(261, 23);
            ConstructMod_EMNTxTBox.TabIndex = 1;
            // 
            // ConstructMod_EQNTxTBox
            // 
            ConstructMod_EQNTxTBox.Location = new Point(233, 151);
            ConstructMod_EQNTxTBox.Multiline = true;
            ConstructMod_EQNTxTBox.Name = "ConstructMod_EQNTxTBox";
            ConstructMod_EQNTxTBox.Size = new Size(456, 46);
            ConstructMod_EQNTxTBox.TabIndex = 1;
            // 
            // ConstructMod_NumOfOpt
            // 
            ConstructMod_NumOfOpt.Font = new Font("Segoe UI Semibold", 9F, FontStyle.Bold, GraphicsUnit.Point);
            ConstructMod_NumOfOpt.Location = new Point(62, 215);
            ConstructMod_NumOfOpt.Name = "ConstructMod_NumOfOpt";
            ConstructMod_NumOfOpt.Size = new Size(172, 25);
            ConstructMod_NumOfOpt.TabIndex = 0;
            ConstructMod_NumOfOpt.Text = "Choose Number of Options";
            // 
            // ConstructMod_OptComboBox
            // 
            ConstructMod_OptComboBox.DropDownStyle = ComboBoxStyle.DropDownList;
            ConstructMod_OptComboBox.FormattingEnabled = true;
            ConstructMod_OptComboBox.Items.AddRange(new object[] { "1", "2", "3", "4" });
            ConstructMod_OptComboBox.Location = new Point(233, 217);
            ConstructMod_OptComboBox.Name = "ConstructMod_OptComboBox";
            ConstructMod_OptComboBox.Size = new Size(84, 23);
            ConstructMod_OptComboBox.TabIndex = 2;
            ConstructMod_OptComboBox.SelectedIndexChanged += ConstructMod_OptComboBox_SelectedIndexChanged;
            // 
            // ConstructMod_EOpt
            // 
            ConstructMod_EOpt.Font = new Font("Segoe UI Semibold", 9F, FontStyle.Bold, GraphicsUnit.Point);
            ConstructMod_EOpt.Location = new Point(136, 255);
            ConstructMod_EOpt.Name = "ConstructMod_EOpt";
            ConstructMod_EOpt.Size = new Size(132, 25);
            ConstructMod_EOpt.TabIndex = 0;
            ConstructMod_EOpt.Text = "Enter Options";
            // 
            // ConstructMod_CorrectAnsLbL
            // 
            ConstructMod_CorrectAnsLbL.Font = new Font("Segoe UI Semibold", 9F, FontStyle.Bold, GraphicsUnit.Point);
            ConstructMod_CorrectAnsLbL.Location = new Point(113, 343);
            ConstructMod_CorrectAnsLbL.Name = "ConstructMod_CorrectAnsLbL";
            ConstructMod_CorrectAnsLbL.Size = new Size(171, 25);
            ConstructMod_CorrectAnsLbL.TabIndex = 0;
            ConstructMod_CorrectAnsLbL.Text = "Set Correct Answer";
            // 
            // ConstructMod_AddQNBTN
            // 
            ConstructMod_AddQNBTN.Location = new Point(274, 484);
            ConstructMod_AddQNBTN.Name = "ConstructMod_AddQNBTN";
            ConstructMod_AddQNBTN.Size = new Size(162, 39);
            ConstructMod_AddQNBTN.TabIndex = 4;
            ConstructMod_AddQNBTN.Text = "Add Question";
            ConstructMod_AddQNBTN.UseVisualStyleBackColor = true;
            ConstructMod_AddQNBTN.Click += ConstructMod_AddQNBTN_Click;
            // 
            // ConstructMod_ConfirmModBTN
            // 
            ConstructMod_ConfirmModBTN.Location = new Point(462, 484);
            ConstructMod_ConfirmModBTN.Name = "ConstructMod_ConfirmModBTN";
            ConstructMod_ConfirmModBTN.Size = new Size(165, 39);
            ConstructMod_ConfirmModBTN.TabIndex = 4;
            ConstructMod_ConfirmModBTN.Text = "Confirm Module";
            ConstructMod_ConfirmModBTN.UseVisualStyleBackColor = true;
            ConstructMod_ConfirmModBTN.Click += ConstructMod_ConfirmModBTN_Click;
            // 
            // ConstructMod_OptATxTBox
            // 
            ConstructMod_OptATxTBox.Location = new Point(251, 255);
            ConstructMod_OptATxTBox.Name = "ConstructMod_OptATxTBox";
            ConstructMod_OptATxTBox.Size = new Size(261, 25);
            ConstructMod_OptATxTBox.TabIndex = 5;
            ConstructMod_OptATxTBox.Text = "";
            ConstructMod_OptATxTBox.Visible = false;
            // 
            // ConstructMod_OptBTxTBox
            // 
            ConstructMod_OptBTxTBox.Location = new Point(541, 255);
            ConstructMod_OptBTxTBox.Name = "ConstructMod_OptBTxTBox";
            ConstructMod_OptBTxTBox.Size = new Size(261, 25);
            ConstructMod_OptBTxTBox.TabIndex = 5;
            ConstructMod_OptBTxTBox.Text = "";
            ConstructMod_OptBTxTBox.Visible = false;
            // 
            // ConstructMod_OptCTxTBox
            // 
            ConstructMod_OptCTxTBox.Location = new Point(251, 297);
            ConstructMod_OptCTxTBox.Name = "ConstructMod_OptCTxTBox";
            ConstructMod_OptCTxTBox.Size = new Size(261, 25);
            ConstructMod_OptCTxTBox.TabIndex = 5;
            ConstructMod_OptCTxTBox.Text = "";
            ConstructMod_OptCTxTBox.Visible = false;
            // 
            // ConstructMod_OptDTxTBox
            // 
            ConstructMod_OptDTxTBox.Location = new Point(541, 297);
            ConstructMod_OptDTxTBox.Name = "ConstructMod_OptDTxTBox";
            ConstructMod_OptDTxTBox.Size = new Size(261, 25);
            ConstructMod_OptDTxTBox.TabIndex = 5;
            ConstructMod_OptDTxTBox.Text = "";
            ConstructMod_OptDTxTBox.Visible = false;
            // 
            // ConstructMod_2OptMust
            // 
            ConstructMod_2OptMust.ForeColor = Color.Red;
            ConstructMod_2OptMust.Location = new Point(323, 217);
            ConstructMod_2OptMust.Name = "ConstructMod_2OptMust";
            ConstructMod_2OptMust.Size = new Size(318, 29);
            ConstructMod_2OptMust.TabIndex = 6;
            // 
            // ConstructMod_ShortExpLbL
            // 
            ConstructMod_ShortExpLbL.Font = new Font("Segoe UI Semibold", 9F, FontStyle.Bold, GraphicsUnit.Point);
            ConstructMod_ShortExpLbL.Location = new Point(97, 389);
            ConstructMod_ShortExpLbL.Name = "ConstructMod_ShortExpLbL";
            ConstructMod_ShortExpLbL.Size = new Size(170, 25);
            ConstructMod_ShortExpLbL.TabIndex = 0;
            ConstructMod_ShortExpLbL.Text = "Set Short Explanation";
            // 
            // ConstructMod_ShortExpTxTBox
            // 
            ConstructMod_ShortExpTxTBox.Location = new Point(234, 393);
            ConstructMod_ShortExpTxTBox.Name = "ConstructMod_ShortExpTxTBox";
            ConstructMod_ShortExpTxTBox.Size = new Size(578, 67);
            ConstructMod_ShortExpTxTBox.TabIndex = 7;
            ConstructMod_ShortExpTxTBox.Text = "";
            // 
            // ConstructMod_OptALbl
            // 
            ConstructMod_OptALbl.AutoSize = true;
            ConstructMod_OptALbl.Location = new Point(230, 258);
            ConstructMod_OptALbl.Name = "ConstructMod_OptALbl";
            ConstructMod_OptALbl.Size = new Size(15, 15);
            ConstructMod_OptALbl.TabIndex = 8;
            ConstructMod_OptALbl.Text = "A";
            ConstructMod_OptALbl.Visible = false;
            // 
            // ConstructMod_OptBLbl
            // 
            ConstructMod_OptBLbl.AutoSize = true;
            ConstructMod_OptBLbl.Location = new Point(522, 255);
            ConstructMod_OptBLbl.Name = "ConstructMod_OptBLbl";
            ConstructMod_OptBLbl.Size = new Size(14, 15);
            ConstructMod_OptBLbl.TabIndex = 8;
            ConstructMod_OptBLbl.Text = "B";
            ConstructMod_OptBLbl.Visible = false;
            // 
            // ConstructMod_OptCLbl
            // 
            ConstructMod_OptCLbl.AutoSize = true;
            ConstructMod_OptCLbl.Location = new Point(230, 297);
            ConstructMod_OptCLbl.Name = "ConstructMod_OptCLbl";
            ConstructMod_OptCLbl.Size = new Size(15, 15);
            ConstructMod_OptCLbl.TabIndex = 8;
            ConstructMod_OptCLbl.Text = "C";
            ConstructMod_OptCLbl.Visible = false;
            // 
            // ConstructMod_OptDLbl
            // 
            ConstructMod_OptDLbl.AutoSize = true;
            ConstructMod_OptDLbl.Location = new Point(522, 297);
            ConstructMod_OptDLbl.Name = "ConstructMod_OptDLbl";
            ConstructMod_OptDLbl.Size = new Size(15, 15);
            ConstructMod_OptDLbl.TabIndex = 8;
            ConstructMod_OptDLbl.Text = "D";
            ConstructMod_OptDLbl.Visible = false;
            // 
            // ConstructMod_OptARBT
            // 
            ConstructMod_OptARBT.AutoSize = true;
            ConstructMod_OptARBT.Location = new Point(234, 343);
            ConstructMod_OptARBT.Name = "ConstructMod_OptARBT";
            ConstructMod_OptARBT.Size = new Size(33, 19);
            ConstructMod_OptARBT.TabIndex = 9;
            ConstructMod_OptARBT.TabStop = true;
            ConstructMod_OptARBT.Text = "A";
            ConstructMod_OptARBT.UseVisualStyleBackColor = true;
            // 
            // ConstructMod_OptBRBT
            // 
            ConstructMod_OptBRBT.AutoSize = true;
            ConstructMod_OptBRBT.Location = new Point(274, 343);
            ConstructMod_OptBRBT.Name = "ConstructMod_OptBRBT";
            ConstructMod_OptBRBT.Size = new Size(32, 19);
            ConstructMod_OptBRBT.TabIndex = 9;
            ConstructMod_OptBRBT.TabStop = true;
            ConstructMod_OptBRBT.Text = "B";
            ConstructMod_OptBRBT.UseVisualStyleBackColor = true;
            // 
            // ConstructMod_OptCRBT
            // 
            ConstructMod_OptCRBT.AutoSize = true;
            ConstructMod_OptCRBT.Location = new Point(312, 343);
            ConstructMod_OptCRBT.Name = "ConstructMod_OptCRBT";
            ConstructMod_OptCRBT.Size = new Size(33, 19);
            ConstructMod_OptCRBT.TabIndex = 9;
            ConstructMod_OptCRBT.TabStop = true;
            ConstructMod_OptCRBT.Text = "C";
            ConstructMod_OptCRBT.UseVisualStyleBackColor = true;
            // 
            // ConstructMod_OptDRBT
            // 
            ConstructMod_OptDRBT.AutoSize = true;
            ConstructMod_OptDRBT.Location = new Point(351, 343);
            ConstructMod_OptDRBT.Name = "ConstructMod_OptDRBT";
            ConstructMod_OptDRBT.Size = new Size(33, 19);
            ConstructMod_OptDRBT.TabIndex = 9;
            ConstructMod_OptDRBT.TabStop = true;
            ConstructMod_OptDRBT.Text = "D";
            ConstructMod_OptDRBT.UseVisualStyleBackColor = true;
            // 
            // button1
            // 
            button1.Location = new Point(647, 484);
            button1.Name = "button1";
            button1.Size = new Size(165, 39);
            button1.TabIndex = 10;
            button1.Text = "Cancel Construction";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click;
            // 
            // ConstructMod
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(975, 562);
            Controls.Add(button1);
            Controls.Add(ConstructMod_OptDRBT);
            Controls.Add(ConstructMod_OptCRBT);
            Controls.Add(ConstructMod_OptBRBT);
            Controls.Add(ConstructMod_OptARBT);
            Controls.Add(ConstructMod_OptBLbl);
            Controls.Add(ConstructMod_OptDLbl);
            Controls.Add(ConstructMod_OptCLbl);
            Controls.Add(ConstructMod_OptALbl);
            Controls.Add(ConstructMod_ShortExpTxTBox);
            Controls.Add(ConstructMod_2OptMust);
            Controls.Add(ConstructMod_OptBTxTBox);
            Controls.Add(ConstructMod_OptDTxTBox);
            Controls.Add(ConstructMod_OptCTxTBox);
            Controls.Add(ConstructMod_OptATxTBox);
            Controls.Add(ConstructMod_ConfirmModBTN);
            Controls.Add(ConstructMod_AddQNBTN);
            Controls.Add(ConstructMod_OptComboBox);
            Controls.Add(ConstructMod_EQNTxTBox);
            Controls.Add(ConstructMod_EMNTxTBox);
            Controls.Add(ConstructMod_ShortExpLbL);
            Controls.Add(ConstructMod_CorrectAnsLbL);
            Controls.Add(ConstructMod_EOpt);
            Controls.Add(ConstructMod_NumOfOpt);
            Controls.Add(ConstructMod_EQ);
            Controls.Add(ConstructMod_EMN);
            Controls.Add(ConstructMod_LbL);
            Name = "ConstructMod";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "D";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label ConstructMod_LbL;
        private Label ConstructMod_EMN;
        private Label ConstructMod_EQ;
        private TextBox ConstructMod_EMNTxTBox;
        private TextBox ConstructMod_EQNTxTBox;
        private Label ConstructMod_NumOfOpt;
        private ComboBox ConstructMod_OptComboBox;
        private Label ConstructMod_EOpt;
        private Label ConstructMod_CorrectAnsLbL;
        private Button ConstructMod_AddQNBTN;
        private Button ConstructMod_ConfirmModBTN;
        private RichTextBox ConstructMod_OptATxTBox;
        private RichTextBox ConstructMod_OptBTxTBox;
        private RichTextBox ConstructMod_OptCTxTBox;
        private RichTextBox ConstructMod_OptDTxTBox;
        private Label ConstructMod_2OptMust;
        private Label ConstructMod_ShortExpLbL;
        private RichTextBox ConstructMod_ShortExpTxTBox;
        private Label ConstructMod_OptALbl;
        private Label ConstructMod_OptBLbl;
        private Label ConstructMod_OptCLbl;
        private Label ConstructMod_OptDLbl;
        private RadioButton ConstructMod_OptARBT;
        private RadioButton ConstructMod_OptBRBT;
        private RadioButton ConstructMod_OptCRBT;
        private RadioButton ConstructMod_OptDRBT;
        private Button button1;
    }
}