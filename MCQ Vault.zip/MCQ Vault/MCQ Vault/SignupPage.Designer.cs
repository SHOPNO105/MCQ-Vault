﻿namespace MCQ_Vault
{
    partial class SignupPage
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            Signup_CreateUNLbL = new Label();
            Signup_CNALbL = new Label();
            Signup_Gender = new Label();
            Signup_Institution = new Label();
            Signup_GenderComboBox = new ComboBox();
            Signup_CNTxTBox = new TextBox();
            Signup_InstitutionTxTBox = new TextBox();
            Signup_RoleRadioLbL = new Label();
            Signup_RoleRadioBTNAuthor = new RadioButton();
            Signup_RoleRadioBTNExaminer = new RadioButton();
            Signup_CreatePassLbL = new Label();
            Signup_ConfirmPassLbL = new Label();
            Signup_CreatePassBox = new TextBox();
            Signup_ConfirmPassBox = new TextBox();
            Signup_ConfirmRegBTN = new Button();
            Signup_TermsLbL = new Label();
            Signup_ConditionsLbL = new LinkLabel();
            Signup_EightCharBool = new Label();
            Signup_MustHaveULNLbL = new Label();
            Signup_PasswordXSame = new Label();
            linkLabel1 = new LinkLabel();
            SuspendLayout();
            // 
            // Signup_CreateUNLbL
            // 
            Signup_CreateUNLbL.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            Signup_CreateUNLbL.Location = new Point(207, 161);
            Signup_CreateUNLbL.Name = "Signup_CreateUNLbL";
            Signup_CreateUNLbL.Size = new Size(160, 23);
            Signup_CreateUNLbL.TabIndex = 0;
            Signup_CreateUNLbL.Text = "Create Username";
            // 
            // Signup_CNALbL
            // 
            Signup_CNALbL.Font = new Font("Segoe UI", 36F, FontStyle.Bold, GraphicsUnit.Point);
            Signup_CNALbL.Location = new Point(198, 37);
            Signup_CNALbL.Name = "Signup_CNALbL";
            Signup_CNALbL.Size = new Size(579, 60);
            Signup_CNALbL.TabIndex = 0;
            Signup_CNALbL.Text = "Create New Account";
            // 
            // Signup_Gender
            // 
            Signup_Gender.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            Signup_Gender.Location = new Point(269, 209);
            Signup_Gender.Name = "Signup_Gender";
            Signup_Gender.Size = new Size(98, 23);
            Signup_Gender.TabIndex = 0;
            Signup_Gender.Text = "Gender";
            // 
            // Signup_Institution
            // 
            Signup_Institution.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            Signup_Institution.Location = new Point(255, 254);
            Signup_Institution.Name = "Signup_Institution";
            Signup_Institution.Size = new Size(112, 23);
            Signup_Institution.TabIndex = 0;
            Signup_Institution.Text = "Institution";
            Signup_Institution.Click += Signup_Institution_Click;
            // 
            // Signup_GenderComboBox
            // 
            Signup_GenderComboBox.DropDownStyle = ComboBoxStyle.DropDownList;
            Signup_GenderComboBox.FormattingEnabled = true;
            Signup_GenderComboBox.Items.AddRange(new object[] { "Male", "Female" });
            Signup_GenderComboBox.Location = new Point(373, 211);
            Signup_GenderComboBox.Name = "Signup_GenderComboBox";
            Signup_GenderComboBox.Size = new Size(103, 23);
            Signup_GenderComboBox.TabIndex = 1;
            // 
            // Signup_CNTxTBox
            // 
            Signup_CNTxTBox.Location = new Point(373, 161);
            Signup_CNTxTBox.Name = "Signup_CNTxTBox";
            Signup_CNTxTBox.PlaceholderText = "Provide Both Numbers and Letters";
            Signup_CNTxTBox.Size = new Size(276, 23);
            Signup_CNTxTBox.TabIndex = 2;
            // 
            // Signup_InstitutionTxTBox
            // 
            Signup_InstitutionTxTBox.Location = new Point(373, 256);
            Signup_InstitutionTxTBox.Name = "Signup_InstitutionTxTBox";
            Signup_InstitutionTxTBox.Size = new Size(276, 23);
            Signup_InstitutionTxTBox.TabIndex = 2;
            // 
            // Signup_RoleRadioLbL
            // 
            Signup_RoleRadioLbL.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            Signup_RoleRadioLbL.Location = new Point(296, 300);
            Signup_RoleRadioLbL.Name = "Signup_RoleRadioLbL";
            Signup_RoleRadioLbL.Size = new Size(71, 23);
            Signup_RoleRadioLbL.TabIndex = 0;
            Signup_RoleRadioLbL.Text = "Role";
            Signup_RoleRadioLbL.Click += Signup_Institution_Click;
            // 
            // Signup_RoleRadioBTNAuthor
            // 
            Signup_RoleRadioBTNAuthor.AutoSize = true;
            Signup_RoleRadioBTNAuthor.Location = new Point(373, 300);
            Signup_RoleRadioBTNAuthor.Name = "Signup_RoleRadioBTNAuthor";
            Signup_RoleRadioBTNAuthor.Size = new Size(62, 19);
            Signup_RoleRadioBTNAuthor.TabIndex = 3;
            Signup_RoleRadioBTNAuthor.TabStop = true;
            Signup_RoleRadioBTNAuthor.Text = "Author";
            Signup_RoleRadioBTNAuthor.UseVisualStyleBackColor = true;
            // 
            // Signup_RoleRadioBTNExaminer
            // 
            Signup_RoleRadioBTNExaminer.AutoSize = true;
            Signup_RoleRadioBTNExaminer.Location = new Point(513, 300);
            Signup_RoleRadioBTNExaminer.Name = "Signup_RoleRadioBTNExaminer";
            Signup_RoleRadioBTNExaminer.Size = new Size(74, 19);
            Signup_RoleRadioBTNExaminer.TabIndex = 3;
            Signup_RoleRadioBTNExaminer.TabStop = true;
            Signup_RoleRadioBTNExaminer.Text = "Examiner";
            Signup_RoleRadioBTNExaminer.UseVisualStyleBackColor = true;
            // 
            // Signup_CreatePassLbL
            // 
            Signup_CreatePassLbL.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            Signup_CreatePassLbL.Location = new Point(207, 342);
            Signup_CreatePassLbL.Name = "Signup_CreatePassLbL";
            Signup_CreatePassLbL.Size = new Size(160, 23);
            Signup_CreatePassLbL.TabIndex = 0;
            Signup_CreatePassLbL.Text = "Create Password";
            // 
            // Signup_ConfirmPassLbL
            // 
            Signup_ConfirmPassLbL.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            Signup_ConfirmPassLbL.Location = new Point(198, 422);
            Signup_ConfirmPassLbL.Name = "Signup_ConfirmPassLbL";
            Signup_ConfirmPassLbL.Size = new Size(169, 23);
            Signup_ConfirmPassLbL.TabIndex = 0;
            Signup_ConfirmPassLbL.Text = "Confirm Password";
            // 
            // Signup_CreatePassBox
            // 
            Signup_CreatePassBox.Location = new Point(373, 342);
            Signup_CreatePassBox.Name = "Signup_CreatePassBox";
            Signup_CreatePassBox.Size = new Size(276, 23);
            Signup_CreatePassBox.TabIndex = 2;
            // 
            // Signup_ConfirmPassBox
            // 
            Signup_ConfirmPassBox.Location = new Point(373, 422);
            Signup_ConfirmPassBox.Name = "Signup_ConfirmPassBox";
            Signup_ConfirmPassBox.Size = new Size(276, 23);
            Signup_ConfirmPassBox.TabIndex = 2;
            // 
            // Signup_ConfirmRegBTN
            // 
            Signup_ConfirmRegBTN.Location = new Point(373, 484);
            Signup_ConfirmRegBTN.Name = "Signup_ConfirmRegBTN";
            Signup_ConfirmRegBTN.Size = new Size(276, 47);
            Signup_ConfirmRegBTN.TabIndex = 4;
            Signup_ConfirmRegBTN.Text = "Confirm Registration";
            Signup_ConfirmRegBTN.UseVisualStyleBackColor = true;
            Signup_ConfirmRegBTN.Click += Signup_ConfirmRegBTN_Click;
            // 
            // Signup_TermsLbL
            // 
            Signup_TermsLbL.Location = new Point(315, 590);
            Signup_TermsLbL.Name = "Signup_TermsLbL";
            Signup_TermsLbL.Size = new Size(303, 20);
            Signup_TermsLbL.TabIndex = 5;
            Signup_TermsLbL.Text = "By Confirming the registration,you're agreeing to our ";
            // 
            // Signup_ConditionsLbL
            // 
            Signup_ConditionsLbL.AutoSize = true;
            Signup_ConditionsLbL.Location = new Point(602, 590);
            Signup_ConditionsLbL.Name = "Signup_ConditionsLbL";
            Signup_ConditionsLbL.Size = new Size(119, 15);
            Signup_ConditionsLbL.TabIndex = 6;
            Signup_ConditionsLbL.TabStop = true;
            Signup_ConditionsLbL.Text = "terms and conditions";
            Signup_ConditionsLbL.LinkClicked += Signup_ConditionsLbL_LinkClicked;
            // 
            // Signup_EightCharBool
            // 
            Signup_EightCharBool.ForeColor = Color.Red;
            Signup_EightCharBool.Location = new Point(373, 368);
            Signup_EightCharBool.Name = "Signup_EightCharBool";
            Signup_EightCharBool.Size = new Size(218, 26);
            Signup_EightCharBool.TabIndex = 7;
            Signup_EightCharBool.Text = "Password Must contain more than 8 characters";
            Signup_EightCharBool.Visible = false;
            // 
            // Signup_MustHaveULNLbL
            // 
            Signup_MustHaveULNLbL.ForeColor = Color.Red;
            Signup_MustHaveULNLbL.Location = new Point(373, 394);
            Signup_MustHaveULNLbL.Name = "Signup_MustHaveULNLbL";
            Signup_MustHaveULNLbL.Size = new Size(360, 23);
            Signup_MustHaveULNLbL.TabIndex = 7;
            Signup_MustHaveULNLbL.Text = "Password must contain UPPERCASE , lowercase and numbers";
            Signup_MustHaveULNLbL.Visible = false;
            // 
            // Signup_PasswordXSame
            // 
            Signup_PasswordXSame.ForeColor = Color.Red;
            Signup_PasswordXSame.Location = new Point(373, 458);
            Signup_PasswordXSame.Name = "Signup_PasswordXSame";
            Signup_PasswordXSame.Size = new Size(360, 23);
            Signup_PasswordXSame.TabIndex = 7;
            Signup_PasswordXSame.Text = "Password Didn't Matched .Recheck matchings";
            Signup_PasswordXSame.Visible = false;
            // 
            // linkLabel1
            // 
            linkLabel1.AutoSize = true;
            linkLabel1.Font = new Font("Segoe UI", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            linkLabel1.LinkColor = Color.FromArgb(192, 0, 192);
            linkLabel1.Location = new Point(397, 551);
            linkLabel1.Name = "linkLabel1";
            linkLabel1.Size = new Size(208, 19);
            linkLabel1.TabIndex = 8;
            linkLabel1.TabStop = true;
            linkLabel1.Text = "Have An Account? Login Instead";
            linkLabel1.LinkClicked += linkLabel1_LinkClicked;
            // 
            // SignupPage
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(889, 639);
            Controls.Add(linkLabel1);
            Controls.Add(Signup_PasswordXSame);
            Controls.Add(Signup_MustHaveULNLbL);
            Controls.Add(Signup_EightCharBool);
            Controls.Add(Signup_ConditionsLbL);
            Controls.Add(Signup_TermsLbL);
            Controls.Add(Signup_ConfirmRegBTN);
            Controls.Add(Signup_RoleRadioBTNExaminer);
            Controls.Add(Signup_RoleRadioBTNAuthor);
            Controls.Add(Signup_ConfirmPassBox);
            Controls.Add(Signup_CreatePassBox);
            Controls.Add(Signup_InstitutionTxTBox);
            Controls.Add(Signup_CNTxTBox);
            Controls.Add(Signup_GenderComboBox);
            Controls.Add(Signup_CNALbL);
            Controls.Add(Signup_RoleRadioLbL);
            Controls.Add(Signup_Institution);
            Controls.Add(Signup_Gender);
            Controls.Add(Signup_ConfirmPassLbL);
            Controls.Add(Signup_CreatePassLbL);
            Controls.Add(Signup_CreateUNLbL);
            Name = "SignupPage";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "SignupPage";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label Signup_CreateUNLbL;
        private Label Signup_CNALbL;
        private Label Signup_Gender;
        private Label Signup_Institution;
        private ComboBox Signup_GenderComboBox;
        private TextBox Signup_CNTxTBox;
        private TextBox Signup_InstitutionTxTBox;
        private Label Signup_RoleRadioLbL;
        private RadioButton Signup_RoleRadioBTNAuthor;
        private RadioButton Signup_RoleRadioBTNExaminer;
        private Label Signup_CreatePassLbL;
        private Label Signup_ConfirmPassLbL;
        private TextBox Signup_CreatePassBox;
        private TextBox Signup_ConfirmPassBox;
        private Button Signup_ConfirmRegBTN;
        private Label Signup_TermsLbL;
        private LinkLabel Signup_ConditionsLbL;
        private Label Signup_EightCharBool;
        private Label Signup_MustHaveULNLbL;
        private Label Signup_PasswordXSame;
        private LinkLabel linkLabel1;
    }
}