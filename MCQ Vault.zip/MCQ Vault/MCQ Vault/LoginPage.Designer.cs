﻿namespace MCQ_Vault
{
    partial class LoginPage
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            WelcomeLabel = new Label();
            InspirationLbL = new Label();
            LoginPage_UsernameTxTBox = new TextBox();
            LoginPageUserName = new Label();
            LoginPage_PassTxTBox = new TextBox();
            LoginPagePassword = new Label();
            LoginPage_Login_Button = new Button();
            LoginPage_Signup_Button = new Button();
            LoginPage_OrLbL = new Label();
            LoginPage_InvalidCredentials = new Label();
            linkLabel1 = new LinkLabel();
            SuspendLayout();
            // 
            // WelcomeLabel
            // 
            WelcomeLabel.Font = new Font("Segoe UI", 36F, FontStyle.Bold, GraphicsUnit.Point);
            WelcomeLabel.Location = new Point(174, 38);
            WelcomeLabel.Name = "WelcomeLabel";
            WelcomeLabel.Size = new Size(674, 79);
            WelcomeLabel.TabIndex = 0;
            WelcomeLabel.Text = "Welcome to MCQ Vault";
            WelcomeLabel.TextAlign = ContentAlignment.TopCenter;
            // 
            // InspirationLbL
            // 
            InspirationLbL.Font = new Font("Segoe UI", 18F, FontStyle.Regular, GraphicsUnit.Point);
            InspirationLbL.Location = new Point(297, 117);
            InspirationLbL.Name = "InspirationLbL";
            InspirationLbL.Size = new Size(514, 50);
            InspirationLbL.TabIndex = 1;
            InspirationLbL.Text = "Sharpen Your Basics and Analytics";
            // 
            // LoginPage_UsernameTxTBox
            // 
            LoginPage_UsernameTxTBox.Location = new Point(366, 211);
            LoginPage_UsernameTxTBox.Name = "LoginPage_UsernameTxTBox";
            LoginPage_UsernameTxTBox.Size = new Size(321, 23);
            LoginPage_UsernameTxTBox.TabIndex = 2;
            // 
            // LoginPageUserName
            // 
            LoginPageUserName.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            LoginPageUserName.Location = new Point(267, 211);
            LoginPageUserName.Name = "LoginPageUserName";
            LoginPageUserName.Size = new Size(100, 23);
            LoginPageUserName.TabIndex = 3;
            LoginPageUserName.Text = "Username";
            // 
            // LoginPage_PassTxTBox
            // 
            LoginPage_PassTxTBox.Location = new Point(366, 259);
            LoginPage_PassTxTBox.Name = "LoginPage_PassTxTBox";
            LoginPage_PassTxTBox.Size = new Size(321, 23);
            LoginPage_PassTxTBox.TabIndex = 2;
            // 
            // LoginPagePassword
            // 
            LoginPagePassword.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            LoginPagePassword.Location = new Point(267, 259);
            LoginPagePassword.Name = "LoginPagePassword";
            LoginPagePassword.Size = new Size(100, 23);
            LoginPagePassword.TabIndex = 3;
            LoginPagePassword.Text = "Password";
            // 
            // LoginPage_Login_Button
            // 
            LoginPage_Login_Button.BackColor = Color.FromArgb(0, 192, 0);
            LoginPage_Login_Button.ForeColor = SystemColors.ControlText;
            LoginPage_Login_Button.Location = new Point(380, 319);
            LoginPage_Login_Button.Name = "LoginPage_Login_Button";
            LoginPage_Login_Button.Size = new Size(91, 39);
            LoginPage_Login_Button.TabIndex = 4;
            LoginPage_Login_Button.Text = "Login";
            LoginPage_Login_Button.UseVisualStyleBackColor = false;
            LoginPage_Login_Button.Click += LoginPage_Login_Button_Click;
            // 
            // LoginPage_Signup_Button
            // 
            LoginPage_Signup_Button.Location = new Point(548, 319);
            LoginPage_Signup_Button.Name = "LoginPage_Signup_Button";
            LoginPage_Signup_Button.Size = new Size(91, 39);
            LoginPage_Signup_Button.TabIndex = 4;
            LoginPage_Signup_Button.Text = "Sign up";
            LoginPage_Signup_Button.UseVisualStyleBackColor = true;
            LoginPage_Signup_Button.Click += LoginPage_Signup_Button_Click;
            // 
            // LoginPage_OrLbL
            // 
            LoginPage_OrLbL.Font = new Font("Segoe UI", 10F, FontStyle.Regular, GraphicsUnit.Point);
            LoginPage_OrLbL.Location = new Point(495, 329);
            LoginPage_OrLbL.Name = "LoginPage_OrLbL";
            LoginPage_OrLbL.Size = new Size(31, 27);
            LoginPage_OrLbL.TabIndex = 1;
            LoginPage_OrLbL.Text = "Or";
            // 
            // LoginPage_InvalidCredentials
            // 
            LoginPage_InvalidCredentials.BackColor = Color.Transparent;
            LoginPage_InvalidCredentials.ForeColor = Color.Red;
            LoginPage_InvalidCredentials.Location = new Point(348, 387);
            LoginPage_InvalidCredentials.Name = "LoginPage_InvalidCredentials";
            LoginPage_InvalidCredentials.Size = new Size(463, 23);
            LoginPage_InvalidCredentials.TabIndex = 5;
            // 
            // linkLabel1
            // 
            linkLabel1.Font = new Font("Segoe UI", 10.8F, FontStyle.Regular, GraphicsUnit.Point);
            linkLabel1.Location = new Point(348, 432);
            linkLabel1.Name = "linkLabel1";
            linkLabel1.Size = new Size(493, 24);
            linkLabel1.TabIndex = 6;
            linkLabel1.TabStop = true;
            linkLabel1.Text = "Don't Have an account ? Click Here to Sign up instead";
            linkLabel1.LinkClicked += linkLabel1_LinkClicked;
            // 
            // LoginPage
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.ControlLight;
            ClientSize = new Size(947, 609);
            Controls.Add(linkLabel1);
            Controls.Add(LoginPage_InvalidCredentials);
            Controls.Add(LoginPage_Signup_Button);
            Controls.Add(LoginPage_Login_Button);
            Controls.Add(LoginPagePassword);
            Controls.Add(LoginPageUserName);
            Controls.Add(LoginPage_PassTxTBox);
            Controls.Add(LoginPage_UsernameTxTBox);
            Controls.Add(LoginPage_OrLbL);
            Controls.Add(InspirationLbL);
            Controls.Add(WelcomeLabel);
            Margin = new Padding(3, 2, 3, 2);
            Name = "LoginPage";
            ShowIcon = false;
            StartPosition = FormStartPosition.CenterScreen;
            Text = "MCQ Vault";
            Load += LoginPage_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label WelcomeLabel;
        private Label InspirationLbL;
        private TextBox LoginPage_UsernameTxTBox;
        private Label LoginPageUserName;
        private TextBox LoginPage_PassTxTBox;
        private Label LoginPagePassword;
        private Button LoginPage_Login_Button;
        private Button LoginPage_Signup_Button;
        private Label LoginPage_OrLbL;
        private Label LoginPage_InvalidCredentials;
        private LinkLabel linkLabel1;
    }
}
