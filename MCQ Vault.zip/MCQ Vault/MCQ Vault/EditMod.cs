﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.Design.AxImporter;

namespace MCQ_Vault
{
    public partial class EditMod : Form
    {
        public EditMod()
        {
            InitializeComponent();
        }

        void AutoCompleteTB()///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        {
            try
            {
                string ModSearching = Enter_Module_Name.Text;


                string Query = "Select * from Module where Module_Name like @ModName and Module_HostId = @host";

                string Connection = @"Data Source=DESKTOP-KVE9T3F\SQLEXPRESS;Initial Catalog=McqVault;Integrated Security=True;TrustServerCertificate=True";
                SqlConnection conn = new SqlConnection(Connection);

                conn.Open();

                SqlCommand ModCmd = new SqlCommand(Query, conn);
                ModCmd.Parameters.Add("@ModName", System.Data.SqlDbType.VarChar, 100).Value = ModSearching + "%";
                ModCmd.Parameters.AddWithValue("@host", UserSession.CurrentUserId);
                SqlDataReader Reader = ModCmd.ExecuteReader();

                AutoCompleteStringCollection coll = new AutoCompleteStringCollection();

                while (Reader.Read())
                {
                    coll.Add(Reader.GetString(0));
                }
                Enter_Module_Name.AutoCompleteSource = AutoCompleteSource.CustomSource;
                Enter_Module_Name.AutoCompleteMode = AutoCompleteMode.SuggestAppend;
                Enter_Module_Name.AutoCompleteCustomSource = coll;

                conn.Close();
            }
            catch (SqlException ex)
            {
                MessageBox.Show(
                    "A database error occurred ." + ex.Message,
                    "Database Error",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error
                );
            }
            catch (Exception ex)
            {
                MessageBox.Show(
                    "An unexpected error occurred ." + ex.Message,
                    "Error",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error
                );
            }

        }

        void AutoCompleteQuesTB()/////////////////////////////////////////////////////////////////////////////////////////////////
        {

            try
            {
                string QuesSearching = Search_Question.Text;


                string Query = "Select Question from Module where Module_Name = @ModName and Module_HostId = @hostID and Question like @ques";
                string Connection = @"Data Source=DESKTOP-KVE9T3F\SQLEXPRESS;Initial Catalog=McqVault;Integrated Security=True;TrustServerCertificate=True;MultipleActiveResultSets=True;";
                SqlConnection conn = new SqlConnection(Connection);

                conn.Open();

                SqlCommand ModCmd = new SqlCommand(Query, conn);

                ModCmd.Parameters.AddWithValue("@ModName", UserSession.CurrentModule);
                ModCmd.Parameters.Add("@ques", SqlDbType.VarChar, 1000).Value = QuesSearching + "%";
                ModCmd.Parameters.AddWithValue("@hostID", UserSession.CurrentUserId);

                SqlDataReader Reader = ModCmd.ExecuteReader();

                AutoCompleteStringCollection Quescoll = new AutoCompleteStringCollection();

                while (Reader.Read())
                {
                    Quescoll.Add(Reader.GetString(0));
                }

                Reader.Close();

                Search_Question.AutoCompleteSource = AutoCompleteSource.CustomSource;
                Search_Question.AutoCompleteMode = AutoCompleteMode.SuggestAppend;
                Search_Question.AutoCompleteCustomSource = Quescoll;

                conn.Close();
            }
            catch (SqlException ex)
            {
                MessageBox.Show(
                    "A database error occurred ." + ex.Message,
                    "Database Error",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error
                );
            }
            catch (Exception ex)
            {
                MessageBox.Show(
                    "An unexpected error occurred ." + ex.Message,
                    "Error",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error
                );
            }
        }

        private void EditMod_Load(object sender, EventArgs e)///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        {
            AutoCompleteTB();
        }

        private void Update_Option_Click(object sender, EventArgs e)////////////////////////////////////////////////////////////////////////////////////////////////////////
        {
            string EditOpt = Edit_Option.Text;
            string SearchQues = Search_Question.Text;
            string Query = "";

            try
            {
                if (Select_Option_Number.SelectedIndex == 0)
                {
                    Query = "update Module SET Option_A = @editOpt,Correct_Answer = Case when Correct_Answer = Option_A THEN @editOpt Else Correct_Answer END Where Question = @Sques";
                }
                else if (Select_Option_Number.SelectedIndex == 1)
                {
                    Query = "update Module SET Option_B = @editOpt,Correct_Answer = Case when Correct_Answer = Option_B THEN @editOpt Else Correct_Answer END Where Question = @Sques";
                }
                else if (Select_Option_Number.SelectedIndex == 2)
                {
                    Query = "update Module SET Option_C = @editOpt,Correct_Answer = Case when Correct_Answer = Option_C THEN @editOpt Else Correct_Answer END Where Question = @Sques";
                }
                else if (Select_Option_Number.SelectedIndex == 3)
                {
                    Query = "update Module SET Option_D = @editOpt,Correct_Answer = Case when Correct_Answer = Option_D THEN @editOpt Else Correct_Answer END Where Question = @Sques";
                }

                string Connection = @"Data Source=DESKTOP-KVE9T3F\SQLEXPRESS;Initial Catalog=McqVault;Integrated Security=True;TrustServerCertificate=True";
                SqlConnection conn = new SqlConnection(Connection);


                conn.Open();
                SqlCommand cmd = new SqlCommand(Query, conn);
                cmd.Parameters.Add("@editOpt", System.Data.SqlDbType.VarChar, 100).Value = EditOpt;
                cmd.Parameters.Add("@Sques", System.Data.SqlDbType.VarChar, 100).Value = SearchQues;
                if (string.IsNullOrEmpty(EditOpt))
                {
                    MessageBox.Show("You Must Enter option to Update");
                }
                DialogResult result = MessageBox.Show("Are you sure you want to update this Option?", "Confirm Update", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if (result == DialogResult.Yes)
                {
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Option updated successfully!");
                }
                else
                {
                    this.Close();
                }

                conn.Close();
            }
            catch (SqlException ex)
            {
                MessageBox.Show(
                    "A database error occurred ." + ex.Message,
                    "Database Error",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error
                );
            }
            catch (Exception ex)
            {
                MessageBox.Show(
                    "An unexpected error occurred ." + ex.Message,
                    "Error",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error
                );
            }

        }

        private void Enter_Module_Name_TextChanged(object sender, EventArgs e)/////////////////////////////////////////////////////////////////////////////////////////////////////////////
        {
            UserSession.CurrentModule = Enter_Module_Name.Text;
            AutoCompleteQuesTB();

        }

        private void Search_Question_TextChanged(object sender, EventArgs e)/////////////////////////////////////////////////////////////////////////////////////////////////////////////
        {
            Edit_Question.Text = Search_Question.Text;
            try
            {
                string OptionQuery = "Select Option_A,Option_B,Option_C,Option_D,Short_Explanation from Module where Module_Name = @ModName and Module_HostId = @hostID and Question like @ques ";

                QuestionSession.StoredOpt1 = new string[1000];
                QuestionSession.StoredOpt2 = new string[1000];
                QuestionSession.StoredOpt3 = new string[1000];
                QuestionSession.StoredOpt4 = new string[1000];
                QuestionSession.StoredShort_Exp = new string[1000];
                string QuesSearching = Search_Question.Text;

                string Connection = @"Data Source=DESKTOP-KVE9T3F\SQLEXPRESS;Initial Catalog=McqVault;Integrated Security=True;TrustServerCertificate=True;";
                SqlConnection conn = new SqlConnection(Connection);

                conn.Open();

                SqlCommand OptCmd = new SqlCommand(OptionQuery, conn);

                OptCmd.Parameters.AddWithValue("@ModName", UserSession.CurrentModule);
                OptCmd.Parameters.Add("@ques", SqlDbType.VarChar, 1000).Value = QuesSearching + "%";
                OptCmd.Parameters.AddWithValue("@hostID", UserSession.CurrentUserId);

                SqlDataReader OptReader = OptCmd.ExecuteReader();

                if (OptReader.Read())
                {
                    QuestionSession.StoredOpt1[0] = OptReader["Option_A"].ToString();
                    QuestionSession.StoredOpt2[0] = OptReader["Option_B"].ToString();
                    QuestionSession.StoredOpt3[0] = OptReader["Option_C"].ToString();
                    QuestionSession.StoredOpt4[0] = OptReader["Option_D"].ToString();
                    QuestionSession.StoredShort_Exp[0] = OptReader["Short_Explanation"].ToString();
                }

                OptReader.Close();

                conn.Close();

                if (Select_Option_Number.SelectedIndex != -1)
                {
                    Select_Option_Number_SelectedIndexChanged(sender, e);
                }
            }
            catch (SqlException ex)
            {
                MessageBox.Show(
                    "A database error occurred ." + ex.Message,
                    "Database Error",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error
                );
            }
            catch (Exception ex)
            {
                MessageBox.Show(
                    "An unexpected error occurred ." + ex.Message,
                    "Error",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error
                );
            }
        }



        private void Delete_Whole_Question_Click(object sender, EventArgs e)/////////////////////////////////////////////////////////////////////////////////////////////////////////////
        {
            string DeleteQues = Edit_Question.Text;
            string SearchQues = Search_Question.Text;

            try
            {
                string Query = "Delete from Module where Question = @Sques ";

                string Connection = @"Data Source=DESKTOP-KVE9T3F\SQLEXPRESS;Initial Catalog=McqVault;Integrated Security=True;TrustServerCertificate=True;";
                SqlConnection conn = new SqlConnection(Connection);


                conn.Open();
                SqlCommand cmd = new SqlCommand(Query, conn);
                cmd.Parameters.Add("@Sques", System.Data.SqlDbType.VarChar, 100).Value = SearchQues;

                if (string.IsNullOrEmpty(DeleteQues))
                {
                    MessageBox.Show("You Must Enter a Question to Delete");
                }
                DialogResult result = MessageBox.Show("Are you sure you want to delete this question?", "delete Update", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if (result == DialogResult.Yes)
                {
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Question Deleted successfully!");
                }
                else
                {
                    this.Close();
                }

                conn.Close();
            }
            catch (SqlException ex)
            {
                MessageBox.Show(
                    "A database error occurred ." + ex.Message,
                    "Database Error",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error
                );
            }
            catch (Exception ex)
            {
                MessageBox.Show(
                    "An unexpected error occurred ." + ex.Message,
                    "Error",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error
                );
            }
        }

        private void Select_Option_Number_SelectedIndexChanged(object sender, EventArgs e)/////////////////////////////////////////////////////////////////////////////////////////////
        {
            if (Select_Option_Number.SelectedIndex == 0)
            {
                Edit_Option.Text = QuestionSession.StoredOpt1[0];
                richTextBox1.Text = QuestionSession.StoredShort_Exp[0];

            }
            else if (Select_Option_Number.SelectedIndex == 1)
            {
                Edit_Option.Text = QuestionSession.StoredOpt2[0];
                richTextBox1.Text = QuestionSession.StoredShort_Exp[0];
            }
            else if (Select_Option_Number.SelectedIndex == 2)
            {
                Edit_Option.Text = QuestionSession.StoredOpt3[0];
                richTextBox1.Text = QuestionSession.StoredShort_Exp[0];
            }
            else if (Select_Option_Number.SelectedIndex == 3)
            {
                Edit_Option.Text = QuestionSession.StoredOpt4[0];
                richTextBox1.Text = QuestionSession.StoredShort_Exp[0];
            }

        }

        private void Update_Question_Click(object sender, EventArgs e)
        {
            string EditQues = Edit_Question.Text;
            string SearchQues = Search_Question.Text;
            if (string.IsNullOrEmpty(EditQues))
            {
                MessageBox.Show("You Must Enter a Question to Update");
            }

            try
            {
                string Query = "Update Module set Question = @editQues where Question = @Sques ";

                string Connection = @"Data Source=DESKTOP-KVE9T3F\SQLEXPRESS;Initial Catalog=McqVault;Integrated Security=True;TrustServerCertificate=True";
                SqlConnection conn = new SqlConnection(Connection);


                conn.Open();
                SqlCommand cmd = new SqlCommand(Query, conn);

                cmd.Parameters.Add("@editQues", System.Data.SqlDbType.VarChar, 100).Value = EditQues;
                cmd.Parameters.Add("@Sques", System.Data.SqlDbType.VarChar, 100).Value = SearchQues;


                DialogResult result = MessageBox.Show("Are you sure you want to update this question?", "Confirm Update", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if (result == DialogResult.Yes)
                {
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Question updated successfully!");
                }
                else
                {
                    this.Close();
                }

                conn.Close();
            }
            catch (SqlException ex)
            {
                MessageBox.Show(
                    "A database error occurred ." + ex.Message,
                    "Database Error",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error
                );
            }
            catch (Exception ex)
            {
                MessageBox.Show(
                    "An unexpected error occurred ." + ex.Message,
                    "Error",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error
                );
            }
        }

        private void Delete_Option_Click(object sender, EventArgs e)
        {
            string DeleteOpt = Edit_Option.Text;
            string SearchQues = Search_Question.Text;
            string Query = "";

            try
            {
                if (Select_Option_Number.SelectedIndex == 0)
                {
                    Query = "Update Module set Option_A = Option_B,Option_B = Option_C,Option_C = Option_D,Option_D = null where Question = @Sques";
                }
                else if (Select_Option_Number.SelectedIndex == 1)
                {
                    Query = "Update Module set Option_B = Option_C,Option_C = Option_D,Option_D = null where Question = @Sques";
                }
                else if (Select_Option_Number.SelectedIndex == 2)
                {
                    Query = "Update Module set Option_C = Option_D,Option_D = null where Question = @Sques";
                }
                else if (Select_Option_Number.SelectedIndex == 3)
                {
                    Query = "Update Module set Option_D = null where Question = @Sques";
                }

                string Connection = @"Data Source=DESKTOP-KVE9T3F\SQLEXPRESS;Initial Catalog=McqVault;Integrated Security=True;TrustServerCertificate=True";
                SqlConnection conn = new SqlConnection(Connection);


                conn.Open();
                SqlCommand cmd = new SqlCommand(Query, conn);
                cmd.Parameters.Add("@Sques", System.Data.SqlDbType.VarChar, 100).Value = SearchQues;

                if (string.IsNullOrEmpty(DeleteOpt))
                {
                    MessageBox.Show("You Must Enter option to Delete");
                }
                DialogResult result = MessageBox.Show("Are you sure you want to Delete this Option?", "Confirm Delete", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if (result == DialogResult.Yes)
                {
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Option Deleted successfully!");
                }
                else
                {
                    this.Close();
                }

                conn.Close();
            }
            catch (SqlException ex)
            {
                MessageBox.Show(
                    "A database error occurred ." + ex.Message,
                    "Database Error",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error
                );
            }
            catch (Exception ex)
            {
                MessageBox.Show(
                    "An unexpected error occurred ." + ex.Message,
                    "Error",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error
                );
            }
        }

        private void Update_Ans_Click(object sender, EventArgs e)
        {
            string EditshortExp = richTextBox1.Text;
            string SearchQues = Search_Question.Text;
            if (string.IsNullOrEmpty(EditshortExp))
            {
                MessageBox.Show("You Must Enter Short Explanation to Update");
            }

            try
            {
                string Query = "Update Module set Short_Explanation =@ShortExp where Question = @Sques ";

                string Connection = @"Data Source=DESKTOP-KVE9T3F\SQLEXPRESS;Initial Catalog=McqVault;Integrated Security=True;TrustServerCertificate=True";
                SqlConnection conn = new SqlConnection(Connection);


                conn.Open();
                SqlCommand cmd = new SqlCommand(Query, conn);

                cmd.Parameters.Add("@ShortExp", System.Data.SqlDbType.VarChar, 100).Value = EditshortExp;
                cmd.Parameters.Add("@Sques", System.Data.SqlDbType.VarChar, 100).Value = SearchQues;


                DialogResult result = MessageBox.Show("Are you sure you want to update Short Explanation?", "Confirm Update", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if (result == DialogResult.Yes)
                {
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Short Explanation updated successfully!");
                }
                else
                {
                    this.Close();
                }

                conn.Close();
            }
            catch (SqlException ex)
            {
                MessageBox.Show(
                    "A database error occurred ." + ex.Message,
                    "Database Error",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error
                );
            }
            catch (Exception ex)
            {
                MessageBox.Show(
                    "An unexpected error occurred ." + ex.Message,
                    "Error",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error
                );
            }

        }

        private void Delete_Ans_Click(object sender, EventArgs e)
        {
            string EditshortExp = richTextBox1.Text;
            string SearchQues = Search_Question.Text;
            if (string.IsNullOrEmpty(EditshortExp))
            {
                MessageBox.Show("You Must Enter Short Explanation to Update");
            }

            try
            {
                string Query = "Update Module set Short_Explanation ='' where Question = @Sques ";

                string Connection = @"Data Source=DESKTOP-KVE9T3F\SQLEXPRESS;Initial Catalog=McqVault;Integrated Security=True;TrustServerCertificate=True";
                SqlConnection conn = new SqlConnection(Connection);


                conn.Open();
                SqlCommand cmd = new SqlCommand(Query, conn);

                cmd.Parameters.Add("@Sques", System.Data.SqlDbType.VarChar, 100).Value = SearchQues;


                DialogResult result = MessageBox.Show("Are you sure you want to Delete Short Explanation?", "Confirm Update", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if (result == DialogResult.Yes)
                {
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Short Explanation deleted successfully!");
                }
                else
                {
                    this.Close();
                }

                conn.Close();
            }
            catch (SqlException ex)
            {
                MessageBox.Show(
                    "A database error occurred ." + ex.Message,
                    "Database Error",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error
                );
            }
            catch (Exception ex)
            {
                MessageBox.Show(
                    "An unexpected error occurred ." + ex.Message,
                    "Error",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error
                );
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            AuthorHP ath = new AuthorHP();
            ath.Show();
            this.Close();
        }
    }
}
