﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MCQ_Vault
{
    public static class UserSession
    {
        public static int CurrentUserId { get; set; }
        public static string CurrentUserName { get; set; }
        public static string CurrentUserType { get; set; }

        public static string CurrentModule {  get; set; }

        public static void ClearUserSession()
        {
            CurrentUserId = 0;
            CurrentUserName = null;
            CurrentUserType = null;
        }
    }
}
