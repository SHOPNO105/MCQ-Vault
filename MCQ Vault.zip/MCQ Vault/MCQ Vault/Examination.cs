﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace MCQ_Vault
{
    public partial class Examination : Form
    {
        private int CurrentQuesIndex = 0;
        public Examination()
        {
            InitializeComponent();
        }

        private void Examination_Load(object sender, EventArgs e)
        {
            QuestionSession.StoredQuestion = new string[1000];
            QuestionSession.StoredOpt1 = new string[1000];
            QuestionSession.StoredOpt2 = new string[1000];
            QuestionSession.StoredOpt3 = new string[1000];
            QuestionSession.StoredOpt4 = new string[1000];
            QuestionSession.StoredAnswer = new string[1000];
            QuestionSession.StoredShort_Exp = new string[1000];


            try
            {

                string ReadQuestionQuery = "Select * from Module where Module_Name = @ModName";

                string Connection = @"Data Source=DESKTOP-KVE9T3F\SQLEXPRESS;Initial Catalog=McqVault;Integrated Security=True;TrustServerCertificate=True";
                SqlConnection conn = new SqlConnection(Connection);

                conn.Open();
                SqlCommand ReadCmd = new SqlCommand(ReadQuestionQuery, conn);
                ReadCmd.Parameters.AddWithValue("@ModName", UserSession.CurrentModule);

                SqlDataReader reader = ReadCmd.ExecuteReader();


                Examination_ModNameHeading.Text = UserSession.CurrentModule;

                int index = 0;

                while (reader.Read())
                {
                    QuestionSession.StoredQuestion[index] = reader["Question"].ToString();
                    QuestionSession.StoredOpt1[index] = reader["Option_A"].ToString();
                    QuestionSession.StoredOpt2[index] = reader["Option_B"].ToString();
                    QuestionSession.StoredOpt3[index] = reader["Option_C"].ToString();
                    QuestionSession.StoredOpt4[index] = reader["Option_D"].ToString();
                    QuestionSession.StoredAnswer[index] = reader["Correct_Answer"].ToString();
                    QuestionSession.StoredShort_Exp[index] = reader["Short_Explanation"].ToString();
                    index++;
                }
                reader.Close();

                QuestionSession.CurrentStoredIndex = index;

                if (QuestionSession.CurrentStoredIndex > 0)
                {
                    CurrentQuesIndex = 0;
                    DisplayQuestion(CurrentQuesIndex);
                }

                conn.Close();
            }
            catch (SqlException ex)
            {
                MessageBox.Show(
                    "A database error occurred ." + ex.Message,
                    "Database Error",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error
                );
            }
            catch (Exception ex)
            {
                MessageBox.Show(
                    "An unexpected error occurred ." + ex.Message,
                    "Error",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error
                );
            }
        }

        private void AnswerCheck(int index)
        {

            string selectedAnswer = null;

            if (Examination_Option1.Checked)
            {
                selectedAnswer = Examination_Option1.Text;
            }
            else if (Examination_Option2.Checked)
            {
                selectedAnswer = Examination_Option2.Text;
            }
            else if (Examination_Option3.Checked)
            {
                selectedAnswer = Examination_Option3.Text;
            }
            else if (Examination_Option4.Checked)
            {
                selectedAnswer = Examination_Option4.Text;
            }

            
            if (selectedAnswer == null)
            {
                Examination_IncorrectAnsLbL.Text = "Select An Answer .Then Procede to Next Question";
            }

            if(selectedAnswer == QuestionSession.StoredAnswer[index])
            {
                Examination_IncorrectAnsLbL.Text = "Correct Answer!";
                Examination_IncorrectAnsLbL.ForeColor = Color.Green;
                Examination_ShortExplanation.Visible = false;
            } else
            {
                Examination_IncorrectAnsLbL.Text = "Incorrect Answer";
                Examination_ShortExplanation.Visible = true;
                Examination_IncorrectAnsLbL.ForeColor = Color.Red;
                Examination_ShortExplanation.Text = QuestionSession.StoredShort_Exp[index];
            }
        }

        private void DisplayQuestion(int index)
        {
            Examination_Question.Text = QuestionSession.StoredQuestion[index];
            Examination_Option1.Text = QuestionSession.StoredOpt1[index];
            Examination_Option2.Text = QuestionSession.StoredOpt2[index];
            Examination_Option3.Text = QuestionSession.StoredOpt3[index];
            Examination_Option4.Text = QuestionSession.StoredOpt4[index];

            Examination_Option1.Checked = false;
            Examination_Option2.Checked = false;
            Examination_Option3.Checked = false;
            Examination_Option4.Checked = false;
            Examination_IncorrectAnsLbL.Text = "";
            Examination_ShortExplanation.Text = "";
            Examination_ShortExplanation.Visible = false;
        }

        private void Examination_PreviousQuesBTN_Click(object sender, EventArgs e)
        {
            if (CurrentQuesIndex < QuestionSession.CurrentStoredIndex)
            {
                CurrentQuesIndex--;
                DisplayQuestion(CurrentQuesIndex);
            }
            else
            {
                MessageBox.Show(" You have reached the Beginning of the module.");
            }
        }

        private void Examination_NextQuesBTN_Click(object sender, EventArgs e)
        {
            
            string Answer = null;
            if (Examination_Option1.Checked)
            {
                Answer = Examination_Option1.Text;
            }
            else if (Examination_Option2.Checked)
            {
                Answer = Examination_Option2.Text;
            }
            else if (Examination_Option3.Checked)
            {
                Answer = Examination_Option3.Text;
            }
            else if (Examination_Option4.Checked)
            {
                Answer = Examination_Option4.Text;
            }

            if (CurrentQuesIndex < QuestionSession.CurrentStoredIndex - 1)
            {
                CurrentQuesIndex++;
                DisplayQuestion(CurrentQuesIndex);
            }
            else
            {
                MessageBox.Show(" You have reached the end of the module.");
            }
        }

        private void Examination_SubmitAnsBTN_Click(object sender, EventArgs e)
        {
            AnswerCheck(CurrentQuesIndex);
            
        }
    }
}
