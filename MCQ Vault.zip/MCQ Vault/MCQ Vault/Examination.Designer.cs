﻿namespace MCQ_Vault
{
    partial class Examination
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            Examination_ModNameHeading = new Label();
            Examination_Question = new Label();
            Examination_Option1 = new RadioButton();
            Examination_Option2 = new RadioButton();
            Examination_Option4 = new RadioButton();
            Examination_ShortExplanation = new Label();
            Examination_Option3 = new RadioButton();
            Examination_NextQuesBTN = new Button();
            Examination_PreviousQuesBTN = new Button();
            Examination_CorrectNum = new Label();
            Examination_IncorrectNum = new Label();
            Examination_SubmitAnsBTN = new Button();
            Examination_IncorrectAnsLbL = new Label();
            SuspendLayout();
            // 
            // Examination_ModNameHeading
            // 
            Examination_ModNameHeading.Font = new Font("Segoe UI", 28.2F, FontStyle.Bold, GraphicsUnit.Point);
            Examination_ModNameHeading.Location = new Point(361, 9);
            Examination_ModNameHeading.Name = "Examination_ModNameHeading";
            Examination_ModNameHeading.Size = new Size(318, 75);
            Examination_ModNameHeading.TabIndex = 0;
            // 
            // Examination_Question
            // 
            Examination_Question.Font = new Font("Segoe UI Semibold", 16.2F, FontStyle.Bold, GraphicsUnit.Point);
            Examination_Question.Location = new Point(56, 104);
            Examination_Question.Name = "Examination_Question";
            Examination_Question.Size = new Size(882, 77);
            Examination_Question.TabIndex = 1;
            // 
            // Examination_Option1
            // 
            Examination_Option1.Font = new Font("Segoe UI", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            Examination_Option1.Location = new Point(56, 197);
            Examination_Option1.Name = "Examination_Option1";
            Examination_Option1.Size = new Size(851, 29);
            Examination_Option1.TabIndex = 2;
            Examination_Option1.TabStop = true;
            Examination_Option1.UseVisualStyleBackColor = true;
            // 
            // Examination_Option2
            // 
            Examination_Option2.Font = new Font("Segoe UI", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            Examination_Option2.Location = new Point(56, 232);
            Examination_Option2.Name = "Examination_Option2";
            Examination_Option2.Size = new Size(851, 29);
            Examination_Option2.TabIndex = 2;
            Examination_Option2.TabStop = true;
            Examination_Option2.UseVisualStyleBackColor = true;
            // 
            // Examination_Option4
            // 
            Examination_Option4.Font = new Font("Segoe UI", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            Examination_Option4.Location = new Point(56, 302);
            Examination_Option4.Name = "Examination_Option4";
            Examination_Option4.Size = new Size(851, 29);
            Examination_Option4.TabIndex = 2;
            Examination_Option4.TabStop = true;
            Examination_Option4.UseVisualStyleBackColor = true;
            // 
            // Examination_ShortExplanation
            // 
            Examination_ShortExplanation.Font = new Font("Segoe UI Semibold", 16.2F, FontStyle.Bold, GraphicsUnit.Point);
            Examination_ShortExplanation.Location = new Point(56, 384);
            Examination_ShortExplanation.Name = "Examination_ShortExplanation";
            Examination_ShortExplanation.Size = new Size(882, 57);
            Examination_ShortExplanation.TabIndex = 1;
            Examination_ShortExplanation.TabStop = true;
            // 
            // Examination_Option3
            // 
            Examination_Option3.Font = new Font("Segoe UI", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            Examination_Option3.Location = new Point(56, 267);
            Examination_Option3.Name = "Examination_Option3";
            Examination_Option3.Size = new Size(851, 29);
            Examination_Option3.TabIndex = 2;
            Examination_Option3.TabStop = true;
            Examination_Option3.UseVisualStyleBackColor = true;
            // 
            // Examination_NextQuesBTN
            // 
            Examination_NextQuesBTN.Location = new Point(571, 453);
            Examination_NextQuesBTN.Name = "Examination_NextQuesBTN";
            Examination_NextQuesBTN.Size = new Size(133, 36);
            Examination_NextQuesBTN.TabIndex = 3;
            Examination_NextQuesBTN.Text = "Next Question";
            Examination_NextQuesBTN.UseVisualStyleBackColor = true;
            Examination_NextQuesBTN.Click += Examination_NextQuesBTN_Click;
            // 
            // Examination_PreviousQuesBTN
            // 
            Examination_PreviousQuesBTN.Location = new Point(268, 453);
            Examination_PreviousQuesBTN.Name = "Examination_PreviousQuesBTN";
            Examination_PreviousQuesBTN.Size = new Size(133, 36);
            Examination_PreviousQuesBTN.TabIndex = 3;
            Examination_PreviousQuesBTN.Text = "Previous Question";
            Examination_PreviousQuesBTN.UseVisualStyleBackColor = true;
            Examination_PreviousQuesBTN.Click += Examination_PreviousQuesBTN_Click;
            // 
            // Examination_CorrectNum
            // 
            Examination_CorrectNum.Font = new Font("Segoe UI Semibold", 10.8F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point);
            Examination_CorrectNum.Location = new Point(730, 9);
            Examination_CorrectNum.Name = "Examination_CorrectNum";
            Examination_CorrectNum.Size = new Size(208, 32);
            Examination_CorrectNum.TabIndex = 4;
            // 
            // Examination_IncorrectNum
            // 
            Examination_IncorrectNum.Font = new Font("Segoe UI Semibold", 10.8F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point);
            Examination_IncorrectNum.Location = new Point(730, 52);
            Examination_IncorrectNum.Name = "Examination_IncorrectNum";
            Examination_IncorrectNum.Size = new Size(208, 32);
            Examination_IncorrectNum.TabIndex = 4;
            // 
            // Examination_SubmitAnsBTN
            // 
            Examination_SubmitAnsBTN.Location = new Point(417, 453);
            Examination_SubmitAnsBTN.Name = "Examination_SubmitAnsBTN";
            Examination_SubmitAnsBTN.Size = new Size(141, 37);
            Examination_SubmitAnsBTN.TabIndex = 5;
            Examination_SubmitAnsBTN.Text = "Submit Answer";
            Examination_SubmitAnsBTN.UseVisualStyleBackColor = true;
            Examination_SubmitAnsBTN.Click += Examination_SubmitAnsBTN_Click;
            // 
            // Examination_IncorrectAnsLbL
            // 
            Examination_IncorrectAnsLbL.ForeColor = Color.Red;
            Examination_IncorrectAnsLbL.Location = new Point(56, 344);
            Examination_IncorrectAnsLbL.Name = "Examination_IncorrectAnsLbL";
            Examination_IncorrectAnsLbL.Size = new Size(225, 31);
            Examination_IncorrectAnsLbL.TabIndex = 6;
            // 
            // Examination
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(976, 502);
            Controls.Add(Examination_IncorrectAnsLbL);
            Controls.Add(Examination_SubmitAnsBTN);
            Controls.Add(Examination_IncorrectNum);
            Controls.Add(Examination_CorrectNum);
            Controls.Add(Examination_PreviousQuesBTN);
            Controls.Add(Examination_NextQuesBTN);
            Controls.Add(Examination_Option4);
            Controls.Add(Examination_Option3);
            Controls.Add(Examination_Option2);
            Controls.Add(Examination_Option1);
            Controls.Add(Examination_ShortExplanation);
            Controls.Add(Examination_Question);
            Controls.Add(Examination_ModNameHeading);
            Name = "Examination";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Form1";
            Load += Examination_Load;
            ResumeLayout(false);
        }

        #endregion

        private Label Examination_ModNameHeading;
        private Label Examination_Question;
        private RadioButton Examination_Option1;
        private RadioButton Examination_Option2;
        private RadioButton Examination_Option4;
        private Label Examination_ShortExplanation;
        private RadioButton Examination_Option3;
        private Button Examination_NextQuesBTN;
        private Button Examination_PreviousQuesBTN;
        private Label Examination_CorrectNum;
        private Label Examination_IncorrectNum;
        private Button Examination_SubmitAnsBTN;
        private Label Examination_IncorrectAnsLbL;
    }
}