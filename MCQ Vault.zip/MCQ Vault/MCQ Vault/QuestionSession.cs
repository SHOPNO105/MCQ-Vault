﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MCQ_Vault
{
    public static class QuestionSession
    {
        public static string[] StoredQuestion {  get; set; }
        public static string[] StoredOpt1 {  get; set; }
        public static string[] StoredOpt2 {  get; set; }
        public static string[] StoredOpt3 { get; set; }
        public static string[] StoredOpt4 {  get; set; }
        public static string[] StoredAnswer {  get; set; }
        public static string[] StoredShort_Exp {  get; set; }
        public static int CurrentStoredIndex {  get; set; }
    }

   
}
